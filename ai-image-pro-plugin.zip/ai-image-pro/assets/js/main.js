"use strict";

// this file is left empty on purpose as it is used to append an inline script to the page where the editor is loaded
// in WordPress, an inline script can only be added to the page if it is linked to a file
