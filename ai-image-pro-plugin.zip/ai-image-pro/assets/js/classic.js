"use strict";

(function() {

    tinymce.PluginManager.add('aiimagepro_classic', function(editor, url) {

        if (typeof aiImagePro === 'undefined') {
            console.log('aiImagePro is undefined');
            return;
        }

        let editorId = Math.random().toString(36).substring(2, 15);
        let pluginVersion = aiImagePro.version;

        editor.addButton('aiimagepro_classic_button_editor', {
            tooltip: 'AI Image Pro',
            image: aiImagePro.pluginUrl + '/assets/icons/ai-image-pro-icon.svg',
            classes: 'ai-image-pro-classic-main-button',
            onclick: function() {
                let width = window.innerWidth * 0.9;
                let height = window.innerHeight * 0.9;

                editor.windowManager.open({
                    body: [
                        {
                            type: 'container',
                            html: '<div class="ai-image-pro-editor-container"></div>',
                            minHeight: height,
                            onPostRender: function() {
                                let iframe = jQuery('<iframe id="ai-image-pro-editor-' + editorId +'" src="' + aiImagePro.editorPageUrl + '&embedded=true&v=' + pluginVersion + '&editorId=' + editorId + '" width="' + width + '" height="' + height + '"></iframe>');
                                iframe.on('load', function() {
                                    onEditorLoad();
                                });

                                jQuery('.ai-image-pro-editor-container').append(iframe);
                            },

                        }
                    ],
                    classes: 'ai-image-pro-classic-modal',
                    width: width,
                    height: height,
                    buttons: [
                        {
                            text: isImageSelected() ? 'Save and replace image' : 'Save and insert',
                            onclick: function(e) {
                                onActionButtonClick(e, isImageSelected() ? 'replace-image' : 'insert-image')
                            },
                            subtype: 'primary',
                            classes: 'ai-image-pro-classic-modal-button ai-image-pro-classic-modal-action-button ai-image-pro-classic-modal-save-and-insert-button ai-image-pro-classic-modal-button-inactive'
                        },
                        {
                            text: 'Cancel',
                            onclick: 'close',
                            subtype: 'secondary',
                            classes: 'ai-image-pro-classic-modal-button'
                        },
                    ]
                });
            }
        });

        const onEditorLoad = function() {
            let selectedNode = editor.selection.getNode();
            if (selectedNode && selectedNode.tagName.toLowerCase() === 'img') {
                let imageClass = selectedNode.getAttribute('class');
                let attachmentId = extractAttachmentId(imageClass);
                if (attachmentId) {
                    sendMessageToEditor('open-image', {id: attachmentId});
                }
            } else {
                let selectedText = editor.selection.getContent({format: 'text'});
                if (selectedText && selectedText.trim().length > 0) {
                    sendMessageToEditor('selected-text', selectedText);
                }
            }
        }

        const isImageSelected = function() {
            let selectedNode = editor.selection.getNode();
            return !!(selectedNode && selectedNode.tagName.toLowerCase() === 'img');
        }

        const onActionButtonClick = function(e, action) {
            let button = jQuery('.mce-ai-image-pro-classic-modal-action-button');
            if (button.hasClass('mce-ai-image-pro-button-inactive')) {
                return;
            }

            // add spinner class and deactivate button
            button.addClass('mce-ai-image-pro-classic-modal-button-spinner-button');
            button.addClass('mce-ai-image-pro-classic-modal-button-inactive');

            sendMessageToEditor('save-and-return-image', {
                noteToSelf: {
                    action: action,
                },
            });

            e.preventDefault();
        }

        const handleMessage = function(event) {
            if (event.data.data.editorId !== editorId) {
                return;
            }

            let actionButton = jQuery('.mce-ai-image-pro-classic-modal-action-button');

            if (event.data.action === 'image') {
                actionButton.addClass('mce-ai-image-pro-classic-modal-button-spinner-button');
                insertOrReplaceImage(event.data.data.id, event.data.data.url, event.data.data.noteToSelf.action);

                actionButton.removeClass('mce-ai-image-pro-classic-modal-button-spinner-button');

                // close the modal
                jQuery('.mce-ai-image-pro-classic-modal-button').click();
            } else if (event.data.action === 'image-added') {
                // remove the inactive class from the button
                actionButton.removeClass('mce-ai-image-pro-classic-modal-button-inactive');
            }
        }

        window.addEventListener('message', handleMessage);

        const insertOrReplaceImage = function(id, url, action) {
            let dom = tinymce.activeEditor.dom;
            let $ = tinymce.dom.DomQuery;

            if (action === 'replace-image') {
                let selectedNode = editor.selection.getNode();
                if (selectedNode.tagName.toLowerCase() === 'img') {
                    dom.setAttrib(selectedNode, 'src', url);
                    dom.setAttrib(selectedNode, 'class', 'wp-image-' + id);
                }
            } else { // insert after selected node
                tinymce.activeEditor.focus();
                tinymce.activeEditor.selection.collapse(false);
                editor.insertContent('<img src="' + url + '" class="wp-image-' + id + '" />');
            }
        }

        const sendMessageToEditor = function (action, data) {
            // get editor iframe
            let editor = document.getElementById("ai-image-pro-editor-" + editorId);

            // send message to editor
            editor.contentWindow.postMessage({
                action: action,
                data: data,
                id: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
            }, '*');
        }

        const extractAttachmentId = function (imageClass) {
            // extract the attachment id from the class
            if (imageClass) {
                let matches = imageClass.match(/wp-image-(\d+)/);
                if (matches && matches.length > 1) {
                    return matches[1];
                }
            }

            return false;
        }
    });
})();
