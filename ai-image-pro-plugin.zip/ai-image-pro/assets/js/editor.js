'use strict';

( function( $ ) {
    const maxImageSideStabilityAI = 1024;
    const maxImageSideDalle = 1024;

    let aiImageProCanvas = null
    let aiImageProMaskCanvas = null;
    let canvasImage = null;
    let availableFilters = [];
    let availableFineTunes = [];
    let isFiltersPaneInitialized = false;
    let isFineTunesPaneInitialized = false;
    let cropper = null;

    // zoom and pan
    let isDraggingEnabled = true;
    let isDragging = false;
    let selection = false;
    let lastPosX = 0;
    let lastPosY = 0;
    let translations = {};
    let saveImageType = null;

    let isUnsavedChanges = false;
    let debug = false;

    let history = {
        states: [],
        current: -1,
        maxSteps: 30
    };

    $(document).ready(async function ($) {
        saveImageType = aiImagePro.saveImageType;
        history.maxSteps = aiImagePro.maxHistoryItems;
        fabric.textureSize = 5000;
        aiImageProCanvas = new fabric.Canvas('ai-image-pro-editor-canvas');
        aiImageProMaskCanvas = new fabric.Canvas('ai-image-pro-mask-canvas');
        let canvasFilters = fabric.Image.filters;
        availableFilters = [
            {
                name: 'Grayscale',
                type: 'Grayscale',
                filter: new canvasFilters.Grayscale(),
                index: 0,
            },
            {
                name: 'Invert',
                type: 'Invert',
                filter: new canvasFilters.Invert(),
                index: 1,
            },
            {
                name: 'Sepia',
                type: 'Sepia',
                filter: new canvasFilters.Sepia(),
                index: 2,
            },
            {
                name: 'Black & White',
                type: 'BlackWhite',
                filter: new canvasFilters.BlackWhite(),
                index: 3,
            },
            {
                name: 'Brownie',
                type: 'Brownie',
                filter: new canvasFilters.Brownie(),
                index: 4,
            },
            {
                name: 'Vintage',
                type: 'Vintage',
                filter: new canvasFilters.Vintage(),
                index: 5,
            },
            {
                name: 'Kodachrome',
                type: 'Kodachrome',
                filter: new canvasFilters.Kodachrome(),
                index: 6,
            },
            {
                name: 'Technicolor',
                type: 'Technicolor',
                filter: new canvasFilters.Technicolor(),
                index: 7,
            },
            {
                name: 'Polaroid',
                type: 'Polaroid',
                filter: new canvasFilters.Polaroid(),
                index: 8,
            },
        ];

        availableFineTunes = [
            {
                name: 'Brightness',
                type: 'Brightness',
                filter: (value) => new canvasFilters.Brightness({brightness: value}),
                retrieveValue: (filter) => filter.brightness,
                min: -1,
                max: 1,
                start: 0,
                index: 20,
            },
            {
                name: 'Contrast',
                type: 'Contrast',
                filter: (value) => new canvasFilters.Contrast({contrast: value}),
                retrieveValue: (filter) => filter.contrast,
                min: -1,
                max: 1,
                start: 0,
                index: 21,
            },
            {
                name: 'Saturation',
                type: 'Saturation',
                filter: (value) => new canvasFilters.Saturation({saturation: value}),
                retrieveValue: (filter) => filter.saturation,
                min: -1,
                max: 1,
                start: 0,
                index: 22,
            },
            {
                name: 'Vibrance',
                type: 'Vibrance',
                filter: (value) => new canvasFilters.Vibrance({vibrance: value}),
                retrieveValue: (filter) => filter.vibrance,
                min: -1,
                max: 1,
                start: 0,
                index: 23,
            },
            {
                name: 'Noise',
                type: 'Noise',
                filter: (value) => new canvasFilters.Noise({noise: parseInt(value, 10)}),
                retrieveValue: (filter) => filter.noise,
                min: 0,
                max: 1000,
                start: 0,
                index: 24,
                step: 1,
            },
            {
                name: 'Pixelate',
                type: 'Pixelate',
                filter: (value) => new canvasFilters.Pixelate({blocksize: parseInt(value, 10)}),
                retrieveValue: (filter) => filter.blocksize,
                min: 1,
                max: 20,
                start: 1,
                index: 25,
            },
            {
                name: 'Blur',
                type: 'Blur',
                filter: (value) => new canvasFilters.Blur({blur: value}),
                retrieveValue: (filter) => filter.blur,
                min: 0,
                max: 1,
                start: 0,
                index: 26,
            },
            {
                name: 'Gamma Red',
                type: 'GammaRed',
                filter: (value) => new canvasFilters.Gamma({gamma: [value, 1, 1]}),
                retrieveValue: (filter) => filter.gamma[0],
                min: 0,
                max: 2,
                start: 1,
                index: 27,
            },
            {
                name: 'Gamma Green',
                type: 'GammaGreen',
                filter: (value) => new canvasFilters.Gamma({gamma: [1, value, 1]}),
                retrieveValue: (filter) => filter.gamma[1],
                min: 0,
                max: 2,
                start: 1,
                index: 28,
            },
            {
                name: 'Gamma Blue',
                type: 'GammaBlue',
                filter: (value) => new canvasFilters.Gamma({gamma: [1, 1, value]}),
                retrieveValue: (filter) => filter.gamma[2],
                min: 0,
                max: 2,
                start: 1,
                index: 29,
            },
            {
                name: 'Hue',
                type: 'HueRotation',
                filter: (value) => new canvasFilters.HueRotation({rotation: value}),
                retrieveValue: (filter) => filter.rotation,
                min: -2,
                max: 2,
                start: 0,
                index: 30,
                step: 0.02,
            }
        ];
        // set the max possible width and height
        let width = $(".ai-image-pro-editor-canvas-container").width();
        let height = $(".ai-image-pro-editor-canvas-container").height();

        // on input change
        $("#ai-image-pro-editor-toolbar-item-brush-size-slider-range").on("input", function () {
            aiImageProMaskCanvas.freeDrawingBrush.width = parseInt($(this).val(), 10) || 1;
        });

        $("#ai-image-pro-editor-toolbar-item-clear-mask-brush").on('click', function () {
            clearMaskCanvas();
        });

        if (debug) {
            $(".ai-image-pro-dev-tools").show();
        }

        aiImageProCanvas.setWidth(width);
        aiImageProCanvas.setHeight(height);

        aiImageProCanvas.on('mouse:wheel', onCanvasMouseWheel);
        aiImageProCanvas.on('mouse:down', onCanvasMouseDown);
        aiImageProCanvas.on('mouse:move', onCanvasMouseMove);
        aiImageProCanvas.on('mouse:up', onCanvasMouseUp);

        aiImageProMaskCanvas.on('mouse:wheel', onCanvasMouseWheel);
        aiImageProMaskCanvas.on('mouse:down', onCanvasMouseDown);
        aiImageProMaskCanvas.on('mouse:move', onCanvasMouseMove);
        aiImageProMaskCanvas.on('mouse:up', onCanvasMouseUp);

        let drawMaskButtonDalle = $('#ai-image-pro-dalle-draw-mask-button');
        let drawMaskButtonStabilityAI = $('#ai-image-pro-stabilityai-draw-mask-button');
        let downloadMaskButton = $('#ai-image-pro-download-mask-button');
        let downloadImageButton = $('#ai-image-pro-download-image-button');
        let performImageEditButtonDalle = $('#ai-image-pro-dalle-perform-edit-button');
        let performImageVariationsButtonDalle = $('#ai-image-pro-dalle-image-variations-button');
        let performImageEditButtonStabilityAI = $('#ai-image-pro-stabilityai-perform-edit-button');
        let filtersButton = $('#ai-image-pro-editor-toolbar-item-filters-button');
        let fineTunesButton = $('#ai-image-pro-editor-toolbar-item-fine-tunes-button');
        let cropButton = $('#ai-image-pro-editor-toolbar-item-crop-button');
        let mediaLibraryButton = $('#ai-image-pro-media-library-button');
        let saveButton = $("#ai-image-pro-save-to-media-gallery-button");
        let upscaleButton = $("#ai-image-pro-stabilityai-upscale-button");

        let dalleModelSelect = $("#ai-image-pro-dalle-generate-models");

        dalleModelSelect.on('change', function (e) {
            if ($(this).val() === 'dall-e-2') {
                $("#ai-image-pro-dalle-generate-image-quality").prop('disabled', true);
                $("#ai-image-pro-dalle-generate-image-styles").prop('disabled', true);
                $("#ai-image-pro-dalle-generate-count").val("1").prop('disabled', false);
                $(".ai-image-pro-range-value").text("1");
            } else {
                $("#ai-image-pro-dalle-generate-image-quality").prop('disabled', false);
                $("#ai-image-pro-dalle-generate-image-styles").prop('disabled', false);
                $("#ai-image-pro-dalle-generate-count").val("1").prop('disabled', true);
                $(".ai-image-pro-range-value").text("1");
            }

            // go through ai-image-pro-dalle-generate-image-size and activate the options that have model name as class and deactivate the others
            $("#ai-image-pro-dalle-generate-image-size option").each(function () {
                if ($(this).hasClass(dalleModelSelect.val())) {
                    $(this).prop('disabled', false);
                } else {
                    $(this).prop('disabled', true);
                }
            });

            // select the first non-disabled option
            $("#ai-image-pro-dalle-generate-image-size option:not(:disabled):first").prop('selected', true);
        });

        dalleModelSelect.trigger('change');

        $('#ai-image-pro-multiple-images-pick-button').on('click', function (e) {
            e.preventDefault();
            let selectedImage = $('.ai-image-pro-multiple-images-selector-image-selected').attr('src');
            if (selectedImage) {
                insertImageIntoEditor(selectedImage);
            }

            hideMultipleImageSelector();
        });

        $('.ai-image-pro-multiple-images-selector-close-button').on('click', function (e) {
            e.preventDefault();
            hideMultipleImageSelector();
        });

        $('#ai-image-pro-dalle-cancel-edit-button').on('click', function (e) {
            e.preventDefault();
            hideMaskCanvas();
        });

        $('#ai-image-pro-undo-button').on('click', function (e) {
            e.preventDefault();
            undo();
        });

        // on input #ai-image-pro-stabilityai-upscale-amount
        $("#ai-image-pro-stabilityai-upscale-amount").on("input", function () {
            // #ai-image-pro-stabilityai-upscale-dimension (select option)
            let upscaleDimension = $("#ai-image-pro-stabilityai-upscale-dimension").val();
            let amount = $(this).val();

            let width = 0;
            let height = 0;

            if (upscaleDimension === "width") {
                width = amount;
                height = Math.round(getImageHeight() * (width / getImageWidth()));
            } else if (upscaleDimension === "height") {
                height = amount;
                width = Math.round(getImageWidth() * (height / getImageHeight()));
            }

            // .ai-image-pro-stabilityai-upscale-new-dimensions
            $("#ai-image-pro-stabilityai-upscale-new-dimensions").text(width + "x" + height);
        });

        $('#ai-image-pro-stabilityai-upscale-dimension').on('change', function (e) {
            updateUpscaleDimensions();
        });


        $('#ai-image-pro-redo-button').on('click', function (e) {
            e.preventDefault();
            redo();
        });

        $('#ai-image-pro-stabilityai-cancel-edit-button').on('click', function (e) {
            e.preventDefault();
            hideMaskCanvas();
        });

        $(function () {
            $('[data-bs-toggle="popover"]').popover({
                delay: { "show": 500, "hide": 100 },
            })

            $('[data-bs-toggle="popover-with-click"]').popover({
                html: true,
            });
        });

        $(window).on('beforeunload', function () {
            if (isUnsavedChanges) {
                return translate('Are you sure you want to leave?');
            }
        });

        assignEventListenersForParentWindowMessages();

        // esc key closes the multiple image selector
        $(document).keyup(function (e) {
            if (e.keyCode === 27) {
                hideMultipleImageSelector();
            }
        });

        $('#ai-image-pro-multiple-images-cancel-button').on('click', function (e) {
            e.preventDefault();
            hideMultipleImageSelector();
        });

        mediaLibraryButton.on('click', function (e) {
            if (hasUnsavedChanges()) {
                return;
            }

            e.preventDefault();
            addImageFromMediaLibrary();
        });

        filtersButton.on('click', function (e) {
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                hideFiltersPane();
            } else {
                $(this).addClass('active');
                // hide the fine tunes pane if it is open
                if (fineTunesButton.hasClass('active')) {
                    fineTunesButton.removeClass('active');
                    hideFineTunesPane();
                }

                // hide the crop pane if it is open
                if (cropButton.hasClass('active')) {
                    cropButton.removeClass('active');
                    hideCropPane();
                }

                showFiltersPane();
            }
        });

        fineTunesButton.on('click', function (e) {
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                hideFineTunesPane();
            } else {
                $(this).addClass('active');
                // hide the filters pane if it is open
                if (filtersButton.hasClass('active')) {
                    filtersButton.removeClass('active');
                    hideFiltersPane();
                }

                // hide the crop pane if it is open
                if (cropButton.hasClass('active')) {
                    cropButton.removeClass('active');
                    hideCropPane();
                }

                showFineTunesPane();
            }
        });

        drawMaskButtonDalle.on('click', function (e) {
            if (!isOpenAIKeySet()) {
                return;
            }

            enableMaskDrawing();
        });

        downloadMaskButton.on('click', function (e) {
            exportMaskAsAlphaPNG();
        });

        downloadImageButton.on('click', function (e) {
            getImageDataUrl(aiImageProCanvas, function (dataUrl) {
                // download image data url
                let link = document.createElement('a');
                link.download = 'image.png';
                link.href = dataUrl;
                link.click();
            }, 1);
        });

        drawMaskButtonStabilityAI.on('click', function (e) {
            if (!isStabilityAIKeySet()) {
                return;
            }

            enableMaskDrawing();
        });

        upscaleButton.on('click', async function (e) {
            let button = $(this);

            let amount = $("#ai-image-pro-stabilityai-upscale-amount").val();
            let upscaleDimension = $("#ai-image-pro-stabilityai-upscale-dimension").val();

            switchBoard('image-upscaling-is-in-progress', button);

            getImageBlob(aiImageProCanvas, async function (imageCanvasBlob) {
                try {

                    let result = await doStabilityAIImageUpscaleRequest(imageCanvasBlob, upscaleDimension, amount);

                    handleGenerationResult(result);

                } catch (error) {
                    alert('An API error occurred with the following response body: \n\n' + error.message);
                } finally {
                    switchBoard('image-upscaling-is-done', button);
                }

            }, null);
        });

        performImageEditButtonStabilityAI.on('click', async function (e) {
            let prompt = $("#ai-image-pro-stabilityai-edit-prompt").val();
            let engine = $("#ai-image-pro-stabilityai-edit-engine").val();
            let sampler = $("#ai-image-pro-stabilityai-edit-sampler").val();
            let imageCount = $("#ai-image-pro-stabilityai-edit-count").val();
            let steps = $("#ai-image-pro-stabilityai-edit-steps").val();
            let cfg = $("#ai-image-pro-stabilityai-edit-cfg").val();
            let seed = $("#ai-image-pro-stabilityai-edit-seed").val();
            let style = $("#ai-image-pro-stabilityai-edit-styles").val();

            if (prompt === "") {
                alert(translate("Please enter a prompt for Stable Diffusion to generate images for."));
                return;
            }

            let button = $(this);
            switchBoard('image-editing-is-in-progress', button);

            getImageDataUrl(aiImageProMaskCanvas, function (maskImage, biggestSideSize) {

                if (biggestSideSize > maxImageSideStabilityAI) {
                    let confirmation = confirm(
                        translate('This image is a bit big for StableDiffusion to edit, so it will be scaled down to 1024px on the biggest side before being edited. Is that OK?')
                    );

                    if (!confirmation) {
                        return;
                    }
                }

                // create a new canvas
                let canvas = document.createElement('canvas');
                let context = canvas.getContext('2d');
                let imageObj = new Image();

                imageObj.onload = async function () {

                    canvas.width = imageObj.width;
                    canvas.height = imageObj.height;

                    context.drawImage(imageObj, 0, 0);

                    let imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                    let maskData = imageData.data;

                    for (let i = 0; i < maskData.length; i += 4) {
                        if (maskData[i + 3] === 0) {  // if the pixel is transparent  TODO: replace the selected mark color instead
                            maskData[i] = 255;
                            maskData[i + 1] = 255;
                            maskData[i + 2] = 255;
                            maskData[i + 3] = 255;
                        } else {
                            maskData[i] = 0;
                            maskData[i + 1] = 0;
                            maskData[i + 2] = 0;
                            maskData[i + 3] = 255;
                        }
                    }

                    context.putImageData(imageData, 0, 0);

                    // get the blob from the canvas
                    let maskCanvasBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));

                    getImageBlob(aiImageProCanvas, async function (imageCanvasBlob) {
                        try {
                            let result = await doStabilityAIImageEditRequest(prompt, engine, sampler, imageCount, steps, cfg, seed, imageCanvasBlob, maskCanvasBlob, style);

                            hideMaskCanvas();
                            handleGenerationResult(result);
                        } catch (error) {
                            alert('An API error occurred with the following response body: \n\n' + error.message);
                        } finally {
                            switchBoard('image-editing-is-done', button);
                        }

                    }, null, maxImageSideStabilityAI);
                };

                imageObj.src = maskImage;

            }, 1, maxImageSideStabilityAI);
        });

        performImageEditButtonDalle.on('click', async function (e) {

            let prompt = $("#ai-image-pro-dalle-edit-prompt").val();
            let size = $("#ai-image-pro-dalle-edit-image-size").val();
            let imageCount = $("#ai-image-pro-dalle-edit-count").val();

            if (prompt === '') {
                alert(translate('Please enter a prompt for Dall.E to generate images for.'));
                return;
            }

            let button = $(this);
            switchBoard('image-editing-is-in-progress', button);

            getImageDataUrl(aiImageProMaskCanvas, async function (maskImage, biggestSideSize, isRectangular) {
                if (!isRectangular) {
                    alert(
                        translate('Dall.E can only edit images that are rectangular and this image is not. Please crop it to a rectangular shape before editing it with Dall.E, or use the Stable Diffusion to edit it instead as it does not have this limitation.')
                    );

                    switchBoard('image-editing-is-done', button);

                    return;
                }

                if (biggestSideSize > maxImageSideDalle) {
                    let confirmation = confirm(
                        translate('This image is a bit big for Dall.E to edit, so it will be scaled down to 1024px on the biggest side before being edited. Is that OK?')
                    );

                    if (!confirmation) {

                        switchBoard('image-editing-is-done', button);
                        return;
                    }
                }

                // create a new canvas
                let canvas = document.createElement('canvas');
                let context = canvas.getContext('2d');
                let imageObj = new Image();

                imageObj.onload = async function () {
                    canvas.width = imageObj.width;
                    canvas.height = imageObj.height;

                    context.drawImage(imageObj, 0, 0);

                    let imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                    let data = imageData.data;

                    for (let i = 0; i < data.length; i += 4) {
                        // if the pixel is black
                        if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 255) {
                            // set the alpha channel to 0
                            data[i + 3] = 0;
                        } else {
                            // set the pixel to white
                            data[i] = 255;
                            data[i + 1] = 255;
                            data[i + 2] = 255;

                            // set the alpha channel to 255
                            data[i + 3] = 255;
                        }
                    }

                    context.putImageData(imageData, 0, 0);

                    // get the blob from the canvas
                    let maskCanvasBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));

                    getImageBlob(aiImageProCanvas, async function (imageCanvasBlob) {
                        try {
                            let result = await doOpenAIImageEditRequest(imageCount, size, prompt, imageCanvasBlob, maskCanvasBlob);

                            hideMaskCanvas();
                            handleGenerationResult(result);

                        } catch (error) {
                            alert('An API error occurred with the following response body: \n\n' + error.message);
                        } finally {
                            switchBoard('image-editing-is-done', button);
                        }

                    }, null, maxImageSideDalle);
                };

                imageObj.src = maskImage;


            }, 1, maxImageSideDalle);
        });

        performImageVariationsButtonDalle.on('click', async function (e) {
            if (!isOpenAIKeySet()) {
                return;
            }

            let size = $("#ai-image-pro-dalle-variations-image-size").val();
            let imageCount = $("#ai-image-pro-dalle-variations-count").val();

            let button = $(this);
            switchBoard('image-variation-generation-is-in-progress', button);

            getImageBlob(aiImageProCanvas, async function (imageCanvasBlob, biggestSideSize, isRectangular) {
                if (!isRectangular) {
                    alert(
                        translate('Dall.E can only edit images that are rectangular and this image is not. Please crop it to a rectangular shape before editing it with Dall.E, or use the Stable Diffusion to edit it instead as it does not have this limitation.')
                    );

                    switchBoard('image-variation-generation-is-done', button);

                    return;
                }

                if (biggestSideSize > maxImageSideDalle) {
                    let confirmation = confirm(
                        translate('This image is a bit big for Dall.E to edit, so it will be scaled down to 1024px on the biggest side before being edited. Is that OK?')
                    );

                    if (!confirmation) {
                        switchBoard('image-variation-generation-is-done', button);

                        return;
                    }
                }

                try {
                    let result = await doOpenAIImageVariationsRequest(imageCount, size, imageCanvasBlob);
                    handleGenerationResult(result);

                } catch (error) {
                    alert('An API error occurred with the following response body: \n\n' + error.message);
                } finally {
                    switchBoard('image-variation-generation-is-done', button);
                }

            }, null, maxImageSideDalle);
        });

        // events
        $("#ai-image-pro-dalle-generate-button").on('click', async function (e) {
            if (!isOpenAIKeySet()) {
                return;
            }

            if (hasUnsavedChanges()) {
                return;
            }

            let prompt = $("#ai-image-pro-dalle-generate-prompt").val();
            let size = $("#ai-image-pro-dalle-generate-image-size").val();
            let imageCount = $("#ai-image-pro-dalle-generate-count").val();
            let model = $("#ai-image-pro-dalle-generate-models").val();
            let imageQuality = $("#ai-image-pro-dalle-generate-image-quality").val();
            let imageStyle = $("#ai-image-pro-dalle-generate-image-styles").val();

            if (prompt === '') {
                alert(translate('Please enter a prompt for Dall.E to generate images for.'));
                return;
            }

            let button = $(this);
            switchBoard('image-generation-is-in-progress', button);

            try {

                let result = await doOpenAIImageGenerationRequest(imageCount, size, prompt, model, imageQuality, imageStyle);

                handleGenerationResult(result);

            } catch (error) {
                alert('An API error occurred with the following response body: \n\n' + error.message);
            } finally {
                switchBoard('image-generation-is-done', button);
            }
        });

        saveButton.on('click', async function (e) {
            saveImage();
        });

        $("#ai-image-pro-stabilityai-generate-button").on('click', async function (e) {
            if (!isStabilityAIKeySet()) {
                return;
            }

            if (hasUnsavedChanges()) {
                return;
            }
            let prompt = $("#ai-image-pro-stabilityai-generate-prompt").val();
            let width = $("#ai-image-pro-stabilityai-generate-image-width").val();
            let height = $("#ai-image-pro-stabilityai-generate-image-height").val();
            let engine = $("#ai-image-pro-stabilityai-generate-engine").val();
            let sampler = $("#ai-image-pro-stabilityai-generate-sampler").val();
            let imageCount = $("#ai-image-pro-stabilityai-generate-count").val();
            let steps = $("#ai-image-pro-stabilityai-generate-steps").val();
            let cfg = $("#ai-image-pro-stabilityai-generate-cfg").val();
            let seed = $("#ai-image-pro-stabilityai-generate-seed").val();
            let style = $("#ai-image-pro-stabilityai-generate-styles").val();

            if (prompt === '') {
                alert(translate('Please enter a prompt for Stable Diffusion to generate images for.'));
                return;
            }

            let button = $(this);
            switchBoard('image-generation-is-in-progress', button);

            try {
                let result = await doStabilityAIImageGenerationRequest(prompt, engine, sampler, width, height, imageCount, steps, cfg, seed, style);

                handleGenerationResult(result);

            } catch (error) {
                alert('An API error occurred with the following response body: \n\n' + error.message);
            } finally {
                switchBoard('image-generation-is-done', button);
            }
        });

        // for all .ai-image-pro-range elements, add  event listener to update the value in the sibling span
        $('.ai-image-pro-range').on('input', function () {
            let value = $(this).val();
            $(this).parent().parent().find('span.ai-image-pro-range-value').text(value);
        });

        // for all .ai-image-pro-range elements, add a change event listener to update the value in the sibling span on page load
        $('.ai-image-pro-range').each(function () {
            let value = $(this).val();
            $(this).parent().parent().find('span.ai-image-pro-range-value').text(value);
        });

        cropButton.on('click', function (e) {

            // if the button is already active, then hide the crop pane
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                hideCropPane();
                return;
            }

            // add a spinner to the button
            let spinner = $('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
            $(this).prepend(spinner);

            showCropPane();

            // hide the other panes
            $('#ai-image-pro-editor-toolbar-pane-filters').hide();
            $('#ai-image-pro-editor-toolbar-pane-fine-tunes').hide();

            // unselect the other buttons
            $('#ai-image-pro-editor-toolbar-item-filters-button').removeClass('active');
            $('#ai-image-pro-editor-toolbar-item-fine-tunes-button').removeClass('active');

            // add an image to the div ai-image-pro-editor-cropper-container
            $('.ai-image-pro-editor-cropper-container').append('<img id="ai-image-pro-editor-cropper-image" src="" />');

            getImageDataUrl(aiImageProCanvas, function (image) {
                // set the image source
                $('#ai-image-pro-editor-cropper-image').attr('src', image);

                // initialize the cropper
                cropper = new Cropper($('#ai-image-pro-editor-cropper-image')[0], {});

                // remove the spinner from the button
                $(spinner).remove();

                isUnsavedChanges = true;

                switchBoard('crop-is-in-progress');
            });
        });

        $('#ai-image-pro-editor-toolbar-item-crop-1-1-ratio').on('click', function (e) {
            if (cropper !== null) {
                if ($('#ai-image-pro-editor-toolbar-item-crop-1-1-ratio').hasClass('active')) {
                    cropper.setAspectRatio(NaN);
                } else {
                    cropper.setAspectRatio(1);
                }

                $('#ai-image-pro-editor-toolbar-item-crop-1-1-ratio').toggleClass('active');
            }

        });

        $('#ai-image-pro-editor-toolbar-item-crop-cancel-button').on('click', function (e) {
            hideCropPane();
            switchBoard('crop-is-done');
        });

        $('#ai-image-pro-editor-toolbar-item-crop-confirm-button').on('click', function (e) {
            // add a spinner to the button
            let spinner = $('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
            $(this).prepend(spinner);

            hideCropPane();

            // get the cropped image from the cropper
            let image = cropper.getCroppedCanvas({}).toDataURL('image/png');

            insertImageIntoEditor(image, function () {
                $(spinner).remove();
                // unselect the button
                cropButton.removeClass('active');

                switchBoard('crop-is-done');
            }, false);
        });

        // if there is a parameter called attachmentId in the URl, load the image
        let urlParams = new URLSearchParams(window.location.search);
        let attachmentId = urlParams.get('attachmentId');
        if (attachmentId) {
            loadImageByAttachmentId(attachmentId);
        }
    });

    /////////////////////////////////////////////////////////////////
    ///////////////////////////// Functions /////////////////////////
    /////////////////////////////////////////////////////////////////

    const onCanvasMouseWheel = (opt) => {
        // zoom in relative to the pointer
        let delta = opt.e.deltaY;
        let zoom = aiImageProMaskCanvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 2) { return }
        if (zoom < 0.1) { return }
        aiImageProMaskCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
        aiImageProCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
    }

    const onCanvasMouseDown = (opt) => {
        if (isDraggingEnabled) {
            let evt = opt.e;
            isDragging = true;
            selection = false;
            lastPosX = evt.clientX;
            lastPosY = evt.clientY;
        }
    }

    const onCanvasMouseMove = (opt) => {
        if (isDragging) {
            let e = opt.e;
            let vpt = aiImageProMaskCanvas.viewportTransform;
            vpt[4] += e.clientX - lastPosX;
            vpt[5] += e.clientY - lastPosY;

            aiImageProMaskCanvas.viewportTransform = vpt;
            aiImageProCanvas.viewportTransform = vpt;
            aiImageProMaskCanvas.requestRenderAll();
            aiImageProCanvas.requestRenderAll();

            lastPosX = e.clientX;
            lastPosY = e.clientY;
        }
    }

    const onCanvasMouseUp = (opt) => {
        // on mouse up we want to recalculate new interaction
        // for all objects, so we call setViewportTransform
        isDragging = false;
        selection = true;
    }

    const insertImageIntoEditor =  function(url, onImageLoaded = null) {
        isUnsavedChanges = false;

        // clear the canvas
        aiImageProCanvas.clear();
        fabric.Image.fromURL(url,  function(img) {

            // resize the image if it is too big for the canvas
            let biggerSide = Math.max(img.width, img.height);
            if (biggerSide > 5000) {
                alert(translate('This image is too big, it will be resized a bit to fit the editor and improve performance.'));
                let scale = 5000 / biggerSide;
                img.scale(scale);
            }

            // reset zoom and pan
            aiImageProCanvas.viewportTransform = [1, 0, 0, 1, 0, 0];
            aiImageProMaskCanvas.viewportTransform = [1, 0, 0, 1, 0, 0];
            // reset zoom
            aiImageProCanvas.setZoom(1);
            aiImageProMaskCanvas.setZoom(1);

            canvasImage = img;
            aiImageProCanvas.add(img);
            aiImageProCanvas.setWidth(img.width);
            aiImageProCanvas.setHeight(img.height);

            updateUpscaleDimensions();

            // resize the mask canvas
            aiImageProMaskCanvas.setWidth(img.width);
            aiImageProMaskCanvas.setHeight(img.height);

            img.scaleToHeight(aiImageProCanvas.getHeight());

            // disable editing in the canvas
            aiImageProCanvas.selection = false;
            aiImageProCanvas.forEachObject(function(o) {
                o.selectable = false;
            });

            clearFiltersPane();
            clearFineTunesPane();

            // if the image is wider or taller than 700px, set the zoom out till it fits
            if (biggerSide > 700) {
                let zoom = 700 / biggerSide;
                aiImageProCanvas.setZoom(zoom);
                aiImageProMaskCanvas.setZoom(zoom);
            }

            if (onImageLoaded !== null) {
                onImageLoaded();
            }

            saveState();

            if (isEmbeddedEditor()) {
                sendMessageToParentWindow('image-added', {});
            }

            switchBoard('image-inserted');

        });
    }

    const updateUpscaleDimensions = function() {
        $('#ai-image-pro-stabilityai-upscale-current-dimensions').text(getImageWidth() + 'x' + getImageHeight());

        let upscaleDimension = $('#ai-image-pro-stabilityai-upscale-dimension').val();

        // max resolution 4194304 pixels, calculate max width and height based on the current width and height
        let maxResolution = 4194304;
        let maxImageWidth = Math.round(Math.sqrt(maxResolution * (getImageWidth() / getImageHeight())));
        let maxImageHeight = Math.round(Math.sqrt(maxResolution * (getImageHeight() / getImageWidth())));

        if (upscaleDimension === 'width') {
            $('#ai-image-pro-stabilityai-upscale-amount').attr('max', maxImageWidth);
            $('#ai-image-pro-stabilityai-upscale-amount').val(getImageWidth());

        } else if (upscaleDimension === 'height') {
            $('#ai-image-pro-stabilityai-upscale-amount').attr('max', maxImageHeight);
            $('#ai-image-pro-stabilityai-upscale-amount').val(getImageHeight());
        }

        $('#ai-image-pro-stabilityai-upscale-amount').trigger('input');

    }

    const enableMaskDrawing = function() {
        showBrushSizeSlider();

        aiImageProMaskCanvas.setWidth(aiImageProCanvas.getWidth());
        aiImageProMaskCanvas.setHeight(aiImageProCanvas.getHeight());

        aiImageProMaskCanvas.isDrawingMode = true;
        aiImageProMaskCanvas.freeDrawingBrush.width = parseInt($('#ai-image-pro-editor-toolbar-item-brush-size-slider-range').val(), 10) || 1;
        aiImageProMaskCanvas.freeDrawingBrush.color = '#000000';  // todo: make this configurable

        showMaskCanvas();

        switchBoard('mask-drawing-enabled');
    }

    const showBrushSizeSlider = function() {
        $('#ai-image-pro-editor-toolbar-item-brush-size-slider').show(100);
        $('.ai-image-pro-editor-edit-image-tip').popover('show');
        setTimeout(function() {
            $('.ai-image-pro-editor-edit-image-tip').popover('hide');
        }, 4000);
    }

    const hideBrushSizeSlider = function() {
        $('#ai-image-pro-editor-toolbar-item-brush-size-slider').hide(100);
        $('.ai-image-pro-editor-edit-image-tip').popover('hide');
    }

    const clearMaskCanvas = function() {
        aiImageProMaskCanvas.clear();
    }

    const disableMaskDrawing = function() {
        aiImageProCanvas.isDrawingMode = false;
    }

    const hideMaskCanvas = function() {
        hideBrushSizeSlider();
        aiImageProMaskCanvas.getElement().style.visibility = 'hidden';
        aiImageProMaskCanvas.isDrawingMode = false;
        // clear the mask canvas
        aiImageProMaskCanvas.clear();
        isDraggingEnabled = true;

        switchBoard('mask-drawing-disabled');
    }

    const showMaskCanvas = function() {
        aiImageProMaskCanvas.getElement().style.visibility = 'visible';
        isDraggingEnabled = false;
    }

    const exportMaskAsAlphaPNG = async function() {

        getImageDataUrl(aiImageProMaskCanvas, function(maskImage) {
            // create a new canvas
            let canvas = document.createElement('canvas');
            let context = canvas.getContext('2d');
            let imageObj = new Image();

            imageObj.onload = function() {
                canvas.width = imageObj.width;
                canvas.height = imageObj.height;

                context.drawImage(imageObj, 0, 0);

                let imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                let data = imageData.data;

                for (let i = 0; i < data.length; i += 4) {
                    // if the pixel is black
                    if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 255) {
                        // set the alpha channel to 0
                        data[i + 3] = 0;
                    } else {
                        // set the pixel to white
                        data[i] = 255;
                        data[i + 1] = 255;
                        data[i + 2] = 255;

                        // set the alpha channel to 255
                        data[i + 3] = 255;
                    }
                }

                context.putImageData(imageData, 0, 0);

                let link = document.createElement('a');
                link.download = 'ai-image-pro-mask.png';
                link.href = canvas.toDataURL({
                    format: 'png',
                })
                link.click();
            };

            imageObj.src = maskImage;
        });
    }

    /**
     * OpenAI
     */
    const doOpenAIImageGenerationRequest = async function (imageCount, imageSize, prompt, model, imageQuality, imageStyle) {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce
        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/openai/v1/generate-images&count=" + imageCount + "&size=" + imageSize, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': nonce,
            },
            body: JSON.stringify({
                prompt: prompt,
                model: model,
                imageQuality: imageQuality,
                imageStyle: imageStyle,
            })
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    const doOpenAIImageEditRequest = async function (imageCount, imageSize, prompt, image, mask) {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        let formData = new FormData();
        formData.append('image', image);
        formData.append('mask', mask);
        formData.append('prompt', prompt);

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/openai/v1/edit-image&count=" + imageCount + "&size=" + imageSize, {
            method: 'POST',
            headers: {
                'X-WP-Nonce': nonce,
            },
            body: formData
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    const doOpenAIImageVariationsRequest = async function (imageCount, imageSize, image) {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        let formData = new FormData();
        formData.append('image', image);

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/openai/v1/image-variations&count=" + imageCount + "&size=" + imageSize, {
            method: 'POST',
            headers: {
                'X-WP-Nonce': nonce,
            },
            body: formData
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    /**
     * Stability AI
     */

    const doStabilityAIImageGenerationRequest = async function (prompt, engine, sampler, width, height, imageCount, steps, cfg, seed, style) {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce
        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/stability-ai/v1/generate-images", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': nonce,
            },
            body: JSON.stringify({
                prompt: prompt,
                engine: engine,
                sampler: sampler,
                width: width,
                height: height,
                imageCount: imageCount,
                steps: steps,
                cfg: cfg,
                seed: seed,
                style: style,
            })
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    const doStabilityAIImageEditRequest = async function (prompt, engine, sampler, imageCount, steps, cfg, seed, image, mask, style)  {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        let formData = new FormData();
        formData.append('image', image);
        formData.append('mask', mask);
        formData.append('prompt', prompt);
        formData.append('engine', engine);
        formData.append('sampler', sampler);
        formData.append('imageCount', imageCount);
        formData.append('steps', steps);
        formData.append('cfg', cfg);
        formData.append('seed', seed);
        formData.append('style', style);

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/stability-ai/v1/edit-image", {
            method: 'POST',
            headers: {
                'X-WP-Nonce': nonce,
            },
            body: formData
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    const doStabilityAIImageUpscaleRequest = async function (image, dimension, amount)  {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        let formData = new FormData();
        formData.append('image', image);
        formData.append('dimension', dimension);
        formData.append('amount', amount);

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/stability-ai/v1/upscale-image", {
            method: 'POST',
            headers: {
                'X-WP-Nonce': nonce,
            },
            body: formData
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        if (data.credits) {
            updateCredits(data.credits);
        }

        return data
    }

    const doGetAttachmentRequest = async function (attachmentId)  {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/get-attachment&id=" + attachmentId, {
            method: 'GET',
            headers: {
                'X-WP-Nonce': nonce,
            },
        }).catch(async error => {
            console.error(await response.text())
            return null;
        })

        if (!response.ok) {
            console.error(await response.text())
            return null;
        }

        return await response.json()
    }

    const updateCredits = function (credits) {
        $('#ai-image-pro-dalle-credits').text(credits.dalle);
        $('#ai-image-pro-stable-diffusion-credits').text(credits.stable_diffusion);
    }

    const handleGenerationResult = function (result) {
        let imageUrls = [];
        for (let image of result.images) {
            imageUrls.push(image.url);
        }

        if (imageUrls.length === 1) {
            insertImageIntoEditor(imageUrls[0]);
        } else {
            showMultipleImageSelector(imageUrls);
        }

        insertImagesIntoImageGenerationsPane(imageUrls);
    }

    const insertImagesIntoImageGenerationsPane = function (imageUrls) {
        let imagePane = $('#ai-image-pro-multiple-images-generations .row');

        for (let imageUrl of imageUrls) {
            let col = $('<div class="col-2"></div>');
            let containerDiv = $('<div class="ai-image-pro-multiple-images-generations-image-container"></div>');
            let image = $('<img class="ai-image-pro-editor-image-history-image" src="' + imageUrl + '" />');
            containerDiv.append(image);
            col.append(containerDiv);
            image.on('click', function () {
                // add a button under the image to insert the image into the editor
                let insertButton = $('<button type="button" class="btn btn-sm btn-success w-100 ai-image-pro-multiple-images-generations-image-use-button">+</button>');
                insertButton.on('click', function () {
                    insertImageIntoEditor(imageUrl);
                    insertButton.remove();
                });

                containerDiv.append(insertButton);

                setTimeout(function () {
                    insertButton.remove();
                }, 5000);
            });
            imagePane.prepend(col);
        }

        $('#ai-image-pro-multiple-images-generations-pane-container').show();
    }

    const doSaveToMediaGalleryRequest = async function (image, imageType) {
        const siteUrl = aiImagePro.siteUrl
        const nonce = aiImagePro.nonce

        let formData = new FormData();
        formData.append('image', image);
        formData.append('imageType', imageType);

        const response = await fetch(siteUrl + "/?rest_route=/aiimagepro/save-image", {
            method: 'POST',
            headers: {
                'X-WP-Nonce': nonce,
            },
            body: formData
        }).catch(async error => {
            throw new Error(await error.text());
        })

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const data = await response.json()

        return data
    }

    /**
     * Toolbar
     * Filters
     */
    const showFiltersPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-filters').show(100);

        if (isFiltersPaneInitialized) {
            updateSelectedFiltersBasedOnCanvas();

            return;
        }

        let multiplierAccordingToWidth = 1 / (aiImageProCanvas.getWidth() / 256);

        getImageDataUrl(aiImageProCanvas, function (image) {
            // for each filter in availableFilters, add a preview image to the filters pane
            for (let i = 0; i < availableFilters.length; i++) {
                // create a fabric canvas on the fly to apply the filter to the image
                let newCanvasContainer = $ ('<div class="ai-image-pro-editor-filter-preview-container" data-filter-type="' + availableFilters[i].type + '"></div>');
                let newCanvasId = 'ai-image-pro-editor-toolbar-pane-filters-preview-image-canvas-' + availableFilters[i].index;
                let newCanvas = $ ('<canvas class="ai-image-pro-editor-filter-preview" id="' + newCanvasId + '" width="65" height="65"></canvas>');

                // add the filter name to the preview image
                let newCanvasName = $ ('<span class="ai-image-pro-editor-filter-preview-name">' + availableFilters[i].name + '</span>');
                newCanvasContainer.append(newCanvas);
                newCanvasContainer.append(newCanvasName);
                // add the canvas to the filters pane
                $('#ai-image-pro-editor-toolbar-pane-filters').append(newCanvasContainer);

                // assign an onclick event to the filter to apply it to the canvas
                newCanvasContainer.on('click', function() {
                    if (hasFilter(aiImageProCanvas, availableFilters[i].type)) {
                        removeFilter(aiImageProCanvas, availableFilters[i].type);
                        newCanvasContainer.removeClass('filter-active')
                    } else {
                        applyFilter(aiImageProCanvas, availableFilters[i].filter);
                        newCanvasContainer.addClass('filter-active')
                    }

                    saveState();

                    isUnsavedChanges = true;

                });

                if (hasFilter(aiImageProCanvas, availableFilters[i].type)) {
                    newCanvasContainer.addClass('filter-active')
                }

                let canvas = new fabric.Canvas(newCanvasId, {
                    selection: false,
                });
                let imageObj = new Image();

                imageObj.onload = function() {
                    fabric.Image.fromURL(imageObj.src, function(img) {
                        // resize the image to fit the canvas
                        img.scaleToWidth(canvas.getWidth());
                        img.scaleToHeight(canvas.getHeight());

                        canvas.add(img);
                        applyFilter(canvas, availableFilters[i].filter);

                        // disable selection
                        canvas.forEachObject(function(o) {
                            o.selectable = false;
                        });
                    });
                }

                imageObj.src = image;
            }

            isFiltersPaneInitialized = true;
        }, multiplierAccordingToWidth);
    }

    const updateSelectedFiltersBasedOnCanvas = function() {
        let filtersPane = $('#ai-image-pro-editor-toolbar-pane-filters');

        filtersPane.find('.ai-image-pro-editor-filter-preview-container').each(function() {
            let filterType = $(this).data('filter-type');

            let filter = hasFilter(aiImageProCanvas, filterType);

            if (filter) {
                $(this).addClass('filter-active');
            } else {
                $(this).removeClass('filter-active');
            }
        });
    }

    const hideFiltersPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-filters').hide(100);
    }

    const clearFiltersPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-filters').empty();
        isFiltersPaneInitialized = false;
        $('#ai-image-pro-editor-toolbar-item-filters-button').removeClass('active');
    }

    /**
     * Toolbar
     * FineTunes
     */

    const showFineTunesPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-fine-tunes').show(100);

        if (isFineTunesPaneInitialized) {
            updateFineTunesBasedOnCanvas();

            return;
        }

        let rangeContainer = $('#ai-image-pro-editor-toolbar-pane-fine-tunes-ranges');
        let buttonsContainer = $('#ai-image-pro-editor-toolbar-pane-fine-tunes-buttons');

        for (let i = 0; i < availableFineTunes.length; i++) {
            // for each fine tune, add a button that shows a range slider when clicked
            let newFineTuneButton = $ ('<button class="ai-image-pro-editor-finetune-button btn btn-outline-secondary btn-sm m-1 mt-2" id="ai-image-pro-editor-finetune-button-' + i + '">' + availableFineTunes[i].name + '</button>');
            buttonsContainer.append(newFineTuneButton);

            // add a div to hold the range slider
            let newFineTuneRangeSliderContainer = $ ('<div class="ai-image-pro-editor-finetune-range-slider" id="ai-image-pro-editor-finetune-range-slider-' + availableFineTunes[i].index + '"></div>');
            rangeContainer.append(newFineTuneRangeSliderContainer);

            // range slider should be hidden by default
            newFineTuneRangeSliderContainer.hide();

            // add a row with a col-4 to the div
            let newFineTuneRangeSliderRow = $ ('<div class="row d-flex justify-content-center"></div>');
            newFineTuneRangeSliderContainer.append(newFineTuneRangeSliderRow);

            // add a col-4 to the row
            let newFineTuneRangeSliderCol = $ ('<div class="col-4 d-flex justify-content-center"></div>');
            newFineTuneRangeSliderRow.append(newFineTuneRangeSliderCol);

            // add a range slider to the div
            let newFineTuneRangeSliderInput = $ ('<input type="range" min="' + availableFineTunes[i].min + '" max="' + availableFineTunes[i].max + '" value="' + availableFineTunes[i].start + '" class="form-range ai-image-pro-editor-finetune-range-slider-input" id="ai-image-pro-editor-finetune-range-slider-input-' + availableFineTunes[i].index + '" data-filter-type="' + availableFineTunes[i].type + '">');

            let step = 0.01;
            if (availableFineTunes[i].step) {
                step = availableFineTunes[i].step;
            }
            newFineTuneRangeSliderInput.attr('step', step);
            newFineTuneRangeSliderCol.append(newFineTuneRangeSliderInput);

            let newFineTuneRangeSliderValueContainer = $ ('<span class="ai-image-pro-editor-finetune-range-slider-value-container" id="ai-image-pro-editor-finetune-range-slider-value-' + availableFineTunes[i].index  + '"></span>');
            newFineTuneRangeSliderCol.append(newFineTuneRangeSliderValueContainer);

            // add a span to show the current value of the range slider
            let newFineTuneRangeSliderValue = $ ('<span class="ai-image-pro-editor-finetune-range-slider-value" id="ai-image-pro-editor-finetune-range-slider-value-' + i + '">' + availableFineTunes[i].start + '</span>');
            newFineTuneRangeSliderValueContainer.append(newFineTuneRangeSliderValue);

            // add a button to reset the range slider to the default value
            let newFineTuneRangeSliderResetButton = $ ('<button type="button" class="btn-close btn-close-white ai-image-pro-editor-finetune-range-slider-reset-button btn-sm" id="ai-image-pro-editor-finetune-range-slider-reset-button-' + i + '" aria-label="Close"></button>');
            newFineTuneRangeSliderCol.prepend(newFineTuneRangeSliderResetButton);

            // assign an onclick event to the reset button to reset the range slider to the default value
            newFineTuneRangeSliderResetButton.on('click', function() {
                newFineTuneRangeSliderInput.val(availableFineTunes[i].start);
                newFineTuneRangeSliderInput.trigger('input');
            });

            // assign an onclick event to the button to show the range slider

            newFineTuneButton.on('click', function() {
                newFineTuneRangeSliderContainer.show();
                //  hide all other range sliders
                $('.ai-image-pro-editor-finetune-range-slider').not(newFineTuneRangeSliderContainer).hide();
                //  remove the active class from all other buttons
                $('.ai-image-pro-editor-finetune-button').not(newFineTuneButton).removeClass('active');
                newFineTuneButton.addClass('active');
            });

            // assign an onchange event to the range slider to apply the value to the canvas
            newFineTuneRangeSliderInput.on('input', function() {
                let filter = availableFineTunes[i].filter($(this).val());
                applyFilter(aiImageProCanvas, filter);
                newFineTuneRangeSliderValue.text($(this).val());

                isUnsavedChanges = true;
            });

            // after the slider has stopped, add the change to history
            newFineTuneRangeSliderInput.on('change', function() {
                saveState();
            });

            // assign an oninput event to the range slider to show the current value
            newFineTuneRangeSliderInput.on('input', function() {
                newFineTuneRangeSliderValue.text($(this).val());
            });
        }

        isFineTunesPaneInitialized = true;
    }

    const updateFineTunesBasedOnCanvas = function() {
        for (let i = 0; i < availableFineTunes.length; i++) {
            let newFineTuneRangeSliderInput = $('#ai-image-pro-editor-finetune-range-slider-input-' + availableFineTunes[i].index);
            let appliedFinetune = hasFilter(aiImageProCanvas, availableFineTunes[i].type);
            let value = availableFineTunes[i].start;

            if (appliedFinetune) {
                value = availableFineTunes[i].retrieveValue(appliedFinetune);
            }

            newFineTuneRangeSliderInput.val(value);
            let newFineTuneRangeSliderValue = $('#ai-image-pro-editor-finetune-range-slider-value-' + availableFineTunes[i].index);
            newFineTuneRangeSliderValue.text(value);
        }
    }

    const hideFineTunesPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-fine-tunes').hide(100);
    }

    const clearFineTunesPane = function() {
        $('#ai-image-pro-editor-toolbar-pane-fine-tunes-buttons').empty();
        $('#ai-image-pro-editor-toolbar-pane-fine-tunes-ranges').empty();
        isFineTunesPaneInitialized = false;
        $('#ai-image-pro-editor-toolbar-item-fine-tunes-button').removeClass('active');
    }

    const showCropPane = function() {
        $('.ai-image-pro-editor-main-canvas-container').hide();
        $('.ai-image-pro-editor-mask-canvas-container').hide();
        $('.ai-image-pro-editor-cropper-container').empty().show();
        $('#ai-image-pro-editor-toolbar-pane-crop').show();
        $('#ai-image-pro-editor-toolbar-item-crop-button').addClass('active');
    }

    const hideCropPane = function() {
        $('.ai-image-pro-editor-cropper-container').hide();
        $('.ai-image-pro-editor-main-canvas-container').show();
        $('.ai-image-pro-editor-mask-canvas-container').show();
        $('#ai-image-pro-editor-toolbar-pane-crop').hide();
        $('#ai-image-pro-editor-toolbar-item-crop-button').removeClass('active');
    }

    /**
     * Filters
     */
    const applyFilter = function (canvas, filter) {
        canvas.forEachObject(function(o) {
            let filterIndex = getFilterIndex(o, filter.type);
            if (filterIndex !== -1) {
                o.filters[filterIndex] = filter;
            } else {
                o.filters.push(filter);
            }

            o.applyFilters();
            canvas.renderAll();
        });
    }

    const removeFilter = function (canvas, type) {
        canvas.forEachObject(function(o) {
            let filterIndex = getFilterIndex(o, type);
            if (filterIndex !== -1) {
                o.filters[filterIndex] = null;
                o.applyFilters();
                canvas.renderAll();
            }
        });
    }

    const hasFilter = function (canvas, type) {
        let filter = null;
        canvas.forEachObject(function(o) {
            let filterIndex = getFilterIndex(o, type);
            if (filterIndex !== -1) {
                filter = o.filters[filterIndex];
            }
        });

        if (filter) {
            return filter;
        }

        return false;
    }

    const getFilterIndex = function (canvasObject, type) {
        for (let i = 0; i < canvasObject.filters.length; i++) {

            if (canvasObject.filters[i] === null) {
                continue;
            }

            // if the filter is Gamma, check whether it is green, red or blue
            if (type.startsWith("Gamma") && canvasObject.filters[i].type === 'Gamma') {  // special case for Gamma filter
                if (canvasObject.filters[i].gamma[0] !== 1 && type === "GammaRed" ) {  // red
                    return i;
                } else if (canvasObject.filters[i].gamma[1] !== 1 && type === "GammaGreen") {  // green
                    return i;
                } else if (canvasObject.filters[i].gamma[2] !== 1 && type === "GammaBlue") {  // blue
                    return i;
                }
            }

            if (canvasObject.filters[i].type === type) {
                return i;
            }
        }

        return -1;
    }

    const addImageFromMediaLibrary = function () {
        let image = wp.media({
            title: 'Select Image',  // todo: localize
            multiple: false
        }).open()
            .on('select', function(e){
                let uploaded_image = image.state().get('selection').first();
                let image_url = uploaded_image.toJSON().url;
                insertImageIntoEditor(image_url);
            });
    }

    const showMultipleImageSelector = function (images) {
        $('#ai-image-pro-multiple-images-selector-container').empty();
        let row = $('<div class="row justify-content-start pe-2"></div>');
        for (let i = 0; i < images.length; i++) {
            let newImage = $('<img class="ai-image-pro-multiple-images-selector-image" src="' + images[i] + '" />');
            // add the image in a bootstrap grid column
            let newImageContainer = $('<div class="col-2"></div>');
            newImageContainer.append(newImage);

            row.append(newImageContainer);

            newImage.on('click', function() {
                // add a border to the selected image
                $('.ai-image-pro-multiple-images-selector-image').removeClass('ai-image-pro-multiple-images-selector-image-selected');
                $(this).addClass('ai-image-pro-multiple-images-selector-image-selected');

                $('#ai-image-pro-multiple-images-pick-button').removeClass('disabled');
            });
        }

        $('#ai-image-pro-multiple-images-selector-container').append(row);

        $('#ai-image-pro-multiple-images-selector').show();
        // add overlay on the content in the background
        $('#ai-image-pro-editor-overlay').show();
    }

    const hideMultipleImageSelector = function () {
        $('#ai-image-pro-multiple-images-selector').hide();
        // remove overlay on the content in the background
        $('#ai-image-pro-editor-overlay').hide();
    }

    const getImageBlob = function (canvas, callback, after, maxSideSize, imageType = 'image/png') {
        canvas.clone(async function(clonedCanvas) {

            // reset zoom and viewport transform
            await clonedCanvas.setZoom(1);
            clonedCanvas.viewportTransform = [1, 0, 0, 1, 0, 0];
            await clonedCanvas.renderAll();

            let biggestSideSize = Math.max(clonedCanvas.width, clonedCanvas.height);
            let isRectangular = clonedCanvas.width === clonedCanvas.height;
            if (maxSideSize && biggestSideSize > maxSideSize) {
                // scale the canvas to the biggest side
                let scale = maxSideSize / biggestSideSize;
                await scaleCanvas(clonedCanvas, scale);
            }

            // get the blob from the canvas
            let imageCanvasBlob = await new Promise(resolve => clonedCanvas.toCanvasElement().toBlob(resolve, imageType));

            await callback(imageCanvasBlob, biggestSideSize, isRectangular);

            if (after) {
                after();
            }
        });
    }

    const getImageDataUrl = function (canvas, callback, multiplier = 1, maxSideSize) {
        canvas.clone(async function(clonedCanvas) {

            // reset zoom and viewport transform
            await clonedCanvas.setZoom(1);
            clonedCanvas.viewportTransform = [1, 0, 0, 1, 0, 0];
            await clonedCanvas.renderAll();

            let biggestSideSize = Math.max(clonedCanvas.width, clonedCanvas.height);
            let isRectangular = clonedCanvas.width === clonedCanvas.height;
            if (maxSideSize && biggestSideSize > maxSideSize) {
                // scale the canvas to the biggest side
                let scale = maxSideSize / biggestSideSize;
                await scaleCanvas(clonedCanvas, scale);
            }

            // get data url from the canvas
            let imageCanvasDataUrl = await clonedCanvas.toDataURL({
                multiplier: multiplier
            });

            await callback(imageCanvasDataUrl, biggestSideSize, isRectangular);

        });
    }

    const scaleCanvas = async function (canvas, scale) {
        // scale everything on the canvas
        // width should multiples of 64
        let width = canvas.width * scale;
        let widthModulo = width % 64;
        if (widthModulo !== 0) {
            scale = scale - (widthModulo / width);
            width = canvas.width * Math.floor(width/64)
        }

        let height = canvas.height * scale;
        let heightModulo = height % 64;
        if (heightModulo !== 0) {
            scale = scale - (heightModulo / height);
            height = canvas.height * Math.floor(height/64)
        }

        canvas.setWidth(width);
        canvas.setHeight(height);
        let objects = canvas.getObjects();
        for (let i in objects) {
            let scaleX = objects[i].scaleX;
            let scaleY = objects[i].scaleY;
            let left = objects[i].left;
            let top = objects[i].top;

            let tempScaleX = scaleX * scale;
            let tempScaleY = scaleY * scale;
            let tempLeft = left * scale;
            let tempTop = top * scale;

            objects[i].scaleX = tempScaleX;
            objects[i].scaleY = tempScaleY;
            objects[i].left = tempLeft;
            objects[i].top = tempTop;

            objects[i].setCoords();
        }

        await canvas.renderAll();
    }

    const translate = function (text) {
        if (typeof translations[text] !== 'undefined') {
            return translations[text];
        }

        return text;
    }

    const switchBoard = function (action, button) {
        let spinner = $('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>');

        if (action === 'image-inserted') {
            enableAllButtons();
        } else if (action === 'image-generation-is-in-progress') {
            button.prepend(spinner);
            disableAllButtons();
        } else if (action === 'image-generation-is-done') {
            button.find('.spinner-border').remove();
            enableAllButtons();
        } else if (action === 'mask-drawing-enabled') {
            $('#ai-image-pro-stabilityai-perform-edit-button').show(100);
            $('#ai-image-pro-dalle-perform-edit-button').show(100);
            $('#ai-image-pro-dalle-cancel-edit-button').show(100);
            $('#ai-image-pro-stabilityai-cancel-edit-button').show(100);
            disableAllButtons();
        } else if (action === 'mask-drawing-disabled') {
            $('#ai-image-pro-stabilityai-perform-edit-button').hide(100);
            $('#ai-image-pro-dalle-perform-edit-button').hide(100);
            $('#ai-image-pro-dalle-cancel-edit-button').hide(100);
            $('#ai-image-pro-stabilityai-cancel-edit-button').hide(100);
            enableAllButtons();
        } else if (action === 'image-editing-is-in-progress') {
            button.prepend(spinner);
            $('#ai-image-pro-dalle-cancel-edit-button').addClass('disabled');
            $('#ai-image-pro-dalle-perform-edit-button').addClass('disabled');
            $('#ai-image-pro-stabilityai-cancel-edit-button').addClass('disabled');
            $('#ai-image-pro-stabilityai-perform-edit-button').addClass('disabled');
        } else if (action === 'image-editing-is-done') {
            button.find('.spinner-border').remove();
            $('#ai-image-pro-dalle-cancel-edit-button').removeClass('disabled');
            $('#ai-image-pro-dalle-perform-edit-button').removeClass('disabled');
            $('#ai-image-pro-stabilityai-cancel-edit-button').removeClass('disabled');
            $('#ai-image-pro-stabilityai-perform-edit-button').removeClass('disabled');
        } else if (action === 'crop-is-in-progress') {
            disableAllButtons();
        } else if (action === 'crop-is-done') {
            enableAllButtons();
        } else if (action === 'image-variation-generation-is-in-progress') {
            button.prepend(spinner);

            disableAllButtons();
        } else if (action === 'image-variation-generation-is-done') {
            button.find('.spinner-border').remove();
            enableAllButtons();
        } else if (action === 'image-upscaling-is-in-progress') {
            button.prepend(spinner);
            disableAllButtons();
        } else if (action === 'image-upscaling-is-done') {
            button.find('.spinner-border').remove();
            enableAllButtons();
        }
    }

    const disableAllButtons = function () {
        $('#ai-image-pro-dalle-image-variations-button').addClass('disabled');
        $('#ai-image-pro-dalle-generate-button').addClass('disabled');
        $('#ai-image-pro-stabilityai-generate-button').addClass('disabled');
        $('#ai-image-pro-dalle-draw-mask-button').addClass('disabled');
        $('#ai-image-pro-stabilityai-draw-mask-button').addClass('disabled');
        $('#ai-image-pro-stabilityai-upscale-button').addClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-crop-button').addClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-filters-button').addClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-fine-tunes-button').addClass('disabled');
        $('#ai-image-pro-save-to-media-gallery-button').addClass('disabled');
        $('#ai-image-pro-download-image-button').addClass('disabled');
        $('#ai-image-pro-undo-button').addClass('disabled');
        $('#ai-image-pro-redo-button').addClass('disabled');
        $('#ai-image-pro-media-library-button').addClass('disabled');
    }

    const enableAllButtons = function () {
        $('#ai-image-pro-dalle-image-variations-button').removeClass('disabled');
        $('#ai-image-pro-dalle-generate-button').removeClass('disabled');
        $('#ai-image-pro-stabilityai-generate-button').removeClass('disabled');
        $('#ai-image-pro-dalle-draw-mask-button').removeClass('disabled');
        $('#ai-image-pro-stabilityai-draw-mask-button').removeClass('disabled');
        $('#ai-image-pro-stabilityai-upscale-button').removeClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-crop-button').removeClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-filters-button').removeClass('disabled');
        $('#ai-image-pro-editor-toolbar-item-fine-tunes-button').removeClass('disabled');
        $('#ai-image-pro-save-to-media-gallery-button').removeClass('disabled');
        $('#ai-image-pro-download-image-button').removeClass('disabled');
        $('#ai-image-pro-undo-button').removeClass('disabled');
        $('#ai-image-pro-redo-button').removeClass('disabled');
        $('#ai-image-pro-media-library-button').removeClass('disabled');
    }

    const hasUnsavedChanges = function () {
        if (isUnsavedChanges) {
            return !confirm(
                translate('You have unsaved changes, are you sure you want to continue?')
            );
        }

        return false;
    }

    const saveState = function() {
        let state = JSON.stringify(
            {
                canvas: aiImageProCanvas.toDatalessJSON([
                    'width', 'height'
                ]),
            }
        );
        if (history.current < history.states.length - 1) {
            history.states.splice(history.current + 1);
        }
        history.states.push(state);
        history.current++;
        if (history.states.length > history.maxSteps) {
            history.states.shift();
            history.current--;
        }

        updateUndoRedoButtons();
    }

    const undo = function() {
        if (history.current > 0) {
            history.current--;
            let state = JSON.parse(history.states[history.current]);
            loadCanvasState(state);
        }

        updateUndoRedoButtons();
    }

    const redo = function() {
        if (history.current < history.states.length - 1) {
            history.current++;
            let state = JSON.parse(history.states[history.current]);
            loadCanvasState(state);
        }

        updateUndoRedoButtons();
    }

    const loadCanvasState = function(state) {
        aiImageProCanvas.loadFromJSON(state.canvas, function() {
            aiImageProCanvas.setWidth(state.canvas.width);
            aiImageProCanvas.setHeight(state.canvas.height);
            aiImageProCanvas.selection = false;
            aiImageProCanvas.forEachObject(function(o) {
                o.selectable = false;
            });
            aiImageProCanvas.renderAll.bind(aiImageProCanvas);

            updateSelectedFiltersBasedOnCanvas();
            updateFineTunesBasedOnCanvas();

            updateUpscaleDimensions();
        });
    }

    const resetHistory = function() {
        history.states = [];
        history.current = -1;

        updateUndoRedoButtons();
    }

    const updateUndoRedoButtons = function() {
        if (history.current > 0) {
            $('#ai-image-pro-undo-button').removeClass('disabled');
        } else {
            $('#ai-image-pro-undo-button').addClass('disabled');
        }

        if (history.current < history.states.length - 1) {
            $('#ai-image-pro-redo-button').removeClass('disabled');
        } else {
            $('#ai-image-pro-redo-button').addClass('disabled');
        }

        // Update the save button
        if (history.current > 0) {
            $('#ai-image-pro-save-to-media-gallery-button').removeClass('disabled');
            $('#ai-image-pro-download-image-button').removeClass('disabled');
        } else {
            $('#ai-image-pro-save-to-media-gallery-button').addClass('disabled');
            $('#ai-image-pro-download-image-button').addClass('disabled');
        }
    }

    const isOpenAIKeySet = function() {
        if (aiImagePro.isOpenAIKeySet === false) {
            let confirmation = confirm(translate('Please enter your OpenAI API key in the settings first. Would you like to go to the settings page now?'));
            if (confirmation) {
                window.location.href = aiImagePro.settingsPageUrl;
            }
            return false;
        }

        return true;
    }

    const isStabilityAIKeySet = function() {
        if (aiImagePro.isStabilityAIKeySet === false) {
            let confirmation = confirm(translate('Please enter your Stability.ai API key in the settings first. Would you like to go to the settings page now?'));
            if (confirmation) {
                window.location.href = aiImagePro.settingsPageUrl;
            }
            return false;
        }

        return true;
    }

    const saveImage = function(callback) {
        let spinner = $('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>');
        let button = $(this);
        button.prepend(spinner);
        button.prop('disabled', true);

        getImageBlob(
            aiImageProCanvas,
            async function (blob) {
                isUnsavedChanges = false;
                let result = await doSaveToMediaGalleryRequest(blob, saveImageType);
                if (callback) {
                    callback(result);
                }
            },
            function () {
                $(spinner).remove();
                button.prop('disabled', false);
            },
            null,
            saveImageType
        );
    }

    const assignEventListenersForParentWindowMessages = function() {
        window.addEventListener('message', function(event) {
            if (event.data.action === 'save-and-return-image') {
                let noteToSelf = event.data.data.noteToSelf || null;
                saveAndReturnImage(noteToSelf);
            } else if (event.data.action === 'selected-text') {
                setPrompt(event.data.data);
            } else if (event.data.action === 'open-image') {
                loadImageByAttachmentId(event.data.data.id);
            }
        });
    }

    const sendMessageToParentWindow = function(action, data) {
        data.editorId = getEditorId();

        window.parent.postMessage({
            action: action,
            data: data,
            id: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
        }, '*');
    }

    const isEmbeddedEditor = function() {
        let urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('embedded') === 'true';
    }

    const saveAndReturnImage = function(noteToSelf) {
        if (canvasImage === null) {
            return;
        }

        saveImage(function (result) {
            sendMessageToParentWindow('image', {
                id: result.id,
                url: result.url,
                noteToSelf: noteToSelf
            })
        });
    }

    const setPrompt = function(prompt) {
        if (prompt) {
            $('#ai-image-pro-stabilityai-generate-prompt').val(prompt);
            $('#ai-image-pro-dalle-generate-prompt').val(prompt);
        }
    }

    const loadImageByAttachmentId = async function(attachmentId) {
        let attachment = await doGetAttachmentRequest(attachmentId);
        if (attachment && attachment.url) {
            let spinner = $('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
            $('#ai-image-pro-media-library-button').prepend(spinner);
            insertImageIntoEditor(attachment.url, function () {
                $(spinner).remove();
            });
        }
    }

    const getEditorId = function() {
        // this is an id that identifies the editor in case there are multiple editors on the same page, which is used to handle messages from the parent window
        let urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('editorId');
    }

    const getImageWidth = function() {
        // loop though objects in aiImageProCanvas and find the image object and get the width

        let objects = aiImageProCanvas.getObjects();
        for (let i in objects) {
            if (objects[i].type === 'image') {
                return objects[i].width;
            }
        }

        // get the width from fabric canvasImage
        return canvasImage.width;
    }

    const getImageHeight = function() {
        // loop though objects in aiImageProCanvas and find the image object and get the height

        let objects = aiImageProCanvas.getObjects();
        for (let i in objects) {
            if (objects[i].type === 'image') {
                return objects[i].height;
            }
        }

        // get the height from fabric canvasImage
        return canvasImage.height;
    }

} )( jQuery );