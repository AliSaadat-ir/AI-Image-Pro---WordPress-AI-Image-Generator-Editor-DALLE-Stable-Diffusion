<?php

namespace AIImagePro\Dependencies\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
