<?php

namespace AIImagePro\Dependencies\GuzzleHttp\Exception;

use AIImagePro\Dependencies\Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
