<?php

namespace AIImagePro\Dependencies\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
