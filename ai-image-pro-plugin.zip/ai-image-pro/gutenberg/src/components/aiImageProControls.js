"use strict";

import { BlockControls } from '@wordpress/block-editor';
import {ToolbarGroup, ToolbarDropdownMenu, ToolbarButton} from '@wordpress/components';
import { createHigherOrderComponent } from '@wordpress/compose';
import {Fragment, useEffect, useState} from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Modal } from '@wordpress/components';
import icons from '../icons.js'


const allowedBlockTypes = [
    'core/code',
    'core/freeform',
    'core/heading',
    'core/list',
    'core/list-item',
    'core/paragraph',
    'core/preformatted',
    'core/image',
];

function insertOrReplaceImage(id, url, action) {

    let selectedBlock = wp.data.select('core/block-editor').getSelectedBlock();
    if (action === 'replace-image' && selectedBlock && selectedBlock.name === 'core/image') {
        wp.data.dispatch('core/block-editor').updateBlockAttributes(selectedBlock.clientId, {
            url: url,
            id: id,
            sizeSlug: 'large',
        });

        return;
    }

    // create a gallery block
    const galleryBlock = wp.blocks.createBlock('core/gallery', {});

    let imageIds = [];
    let imageObjects = [];

    galleryBlock.innerBlocks.push(wp.blocks.createBlock('core/image', {
        url: url,
        id: id,
    }));
    imageIds.push(id);
    imageObjects.push({
        id: id,
        fullUrl: url,
        url: url,
        sizeSlug: 'full',
    });

    // add the image ids to the gallery block attributes
    galleryBlock.attributes.ids = imageIds;
    galleryBlock.attributes.images = imageObjects;

    let selectedBlockIndex = wp.data.select('core/block-editor').getBlockIndex(selectedBlock.clientId);

    // insert the gallery block into the editor at the current cursor position
    wp.data.dispatch('core/block-editor').insertBlock(galleryBlock, selectedBlockIndex + 1);
}

function onEditorLoad (componentName) {
    if (componentName === 'core/image') { // image
        // get the image id from the image block
        let imageBlock = wp.data.select('core/block-editor').getSelectedBlock();
        let imageId = imageBlock.attributes.id;

        sendMessageToEditor('open-image', {id: imageId});

    } else { // text
        let selectedText = getSelectedText();
        if (selectedText && selectedText.trim().length > 0) {
            sendMessageToEditor('selected-text', selectedText);
        }
    }
}

function getSelectedText() {
    let selectedText = getSelectedBlockContents();

    if (selectedText.length > 0) {
        return selectedText;
    }

    return false;
}

function getSelectedBlockContents() {
    let multiSelectedBlockClientIds = getSelectedBlockClientIds();
    let [selectionStart, selectionEnd] = getAdjustedSelections(multiSelectedBlockClientIds);

    let allContent = getAllBlockContentsRecursively(
        multiSelectedBlockClientIds,
        selectionStart,
        selectionEnd
    );

    return allContent.trim();
}

function getAllBlockContentsRecursively(blockClientIds, selectionStart, selectionEnd) {
    let content = '';
    blockClientIds.forEach(blockClientId => {
        const block = wp.data.select( 'core/block-editor' ).getBlock(blockClientId);
        let contentOfBlock = extractBlockContent(block);

        const richText = wp.richText.create( { html: contentOfBlock } );

        let plainText = richText.text;
        let start = 0;
        let end = plainText.length;

        if (selectionStart.clientId === blockClientId && 'offset' in selectionStart) {
            start = selectionStart.offset;
        }

        if (selectionEnd.clientId === blockClientId && 'offset' in selectionEnd) {
            end = selectionEnd.offset;
        }

        plainText = plainText.substring(start, end);

        content += "\n" + plainText;
        if (block.innerBlocks.length > 0) {
            content += getAllBlockContentsRecursively(block.innerBlocks.map(block => block.clientId));
        }
    });

    return content;
}

function extractBlockContent(block) {
    let content = '';
    if ('content' in block.attributes) {
        content = block.attributes.content;
    } else if ('citation' in block.attributes) {
        content = block.attributes.citation;
    } else if ('value' in block.attributes) {
        content = block.attributes.value;
    } else if ('values' in block.attributes) {
        content = block.attributes.values;
    } else if ('text' in block.attributes) {
        content = block.attributes.text;
    }

    return content;
}

function getSelectedBlockClientIds() {
    let selectedBlockClientIds = wp.data.select('core/block-editor').getMultiSelectedBlockClientIds();

    if (selectedBlockClientIds.length === 0) {
        selectedBlockClientIds = [wp.data.select('core/block-editor').getSelectedBlockClientId()];
    }

    return selectedBlockClientIds;
}

function getAdjustedSelections(selectedBlockClientIds) {
    const selectionStart = wp.data.select( 'core/block-editor' ).getSelectionStart();
    const selectionEnd = wp.data.select( 'core/block-editor' ).getSelectionEnd();

    if (selectionStart.clientId === selectionEnd.clientId) {
        return [selectionStart, selectionEnd];
    }

    let adjustedSelectionStart = selectionStart;
    let adjustedSelectionEnd = selectionEnd;
    if (selectedBlockClientIds.length > 0 && selectedBlockClientIds[0] === selectionEnd.clientId) {
        adjustedSelectionStart = selectionEnd;
        adjustedSelectionEnd = selectionStart;
    }

    return [adjustedSelectionStart, adjustedSelectionEnd];
}

function sendMessageToEditor(action, data) {
    // get editor iframe
    let editor = document.getElementById('ai-image-pro-editor');

    // send message to editor
    editor.contentWindow.postMessage({
        action: action,
        data: data,
        id: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
    }, '*');
}

export default createHigherOrderComponent( ( BlockEdit ) => {
    return ( props ) => {

        if (!allowedBlockTypes.includes(props.name)) {
            return <BlockEdit { ...props } />;
        }

        if (typeof aiImagePro === 'undefined') {
            console.log('aiImagePro is undefined');
            return <BlockEdit { ...props } />;
        }

        const [ isSelectionModalOpen, setSelectionModalState ] = useState( false );
        const [ modalInstanceId, setModalInstanceId ] = useState( null );

        const openEditorModal = (instanceId) => {
            setModalInstanceId(instanceId);
            setSelectionModalState( true );
        }
        const closeEditorModal = () => {
            setModalInstanceId(null);
            setSelectionModalState( false );
        }

        useEffect(() => {
            let handleMessage = function(event) {
                if (event.data.data.editorId !== modalInstanceId) {
                    return;
                }

                let actionButton = document.getElementsByClassName('ai-image-pro-button');

                if (event.data.action === 'image') {
                    insertOrReplaceImage(event.data.data.id, event.data.data.url, event.data.data.noteToSelf.action);
                    // close the modal
                    if (actionButton.length > 0) {
                        actionButton[0].classList.remove('ai-image-pro-button-inactive');
                    }

                    closeEditorModal();
                } else if (event.data.action === 'image-added') {
                    // remove the inactive class from the button
                    if (actionButton.length > 0) {
                        actionButton[0].classList.remove('ai-image-pro-button-inactive');
                    }
                }
            }

            window.addEventListener('message', handleMessage);

            return () => {
                window.removeEventListener('message', handleMessage);
            };
        }, [modalInstanceId]);

        function onMainEditorActionButton (componentName) {
            // if ai-image-pro-button-inactive class is present, do nothing (inactive button)
            let button = document.getElementsByClassName('ai-image-pro-button');
            if (button.length > 0) {
                if (button[0].classList.contains('ai-image-pro-button-inactive')) {
                    return;
                }

                // add spinner class and deactivate button
                button[0].classList.add('ai-image-pro-button-spinner-button');
                button[0].classList.add('ai-image-pro-button-inactive');
            }

            let action = 'insert-image';
            if (componentName === 'core/image') { // we are editing an existing image
                action = 'replace-image';
            }

            sendMessageToEditor('save-and-return-image', {
                noteToSelf: {
                    action: action,
                    sourceComponent: componentName,
                    sourceComponentClientId: props.clientId,
                },
            });
        }

        let windowWidth = window.innerWidth - 100;
        let windowHeight = window.innerHeight - 100;
        let version = aiImagePro.version;
        let editorId = props.clientId;

        return (
            <Fragment>
                <BlockEdit { ...props } />
                <BlockControls group="block">
                    <ToolbarGroup>
                        <ToolbarButton
                            icon={ icons.aiImagePro }
                            label={__("AI Image Pro", "ai-image-pro")}
                            onClick={ () => {
                                    openEditorModal(props.clientId);
                                }
                            }
                        />
                    </ToolbarGroup>
                    { isSelectionModalOpen && (
                        <Modal isDismissible={false} onRequestClose={ closeEditorModal } shouldCloseOnClickOutside={false} className={'ai-image-pro-gutenberg-modal'}>
                            <iframe id={"ai-image-pro-editor"} src={ aiImagePro.editorPageUrl + '&embedded=true&v=' + version + '&editorId=' + editorId} style={{width: windowWidth + 'px', height: windowHeight + 'px', }} onLoad={() => onEditorLoad(props.name)}></iframe>
                            <div className="ai-image-pro-bottom-bar">
                                <Button variant="primary" className="components-button is-primary ai-image-pro-button ai-image-pro-button-action-button ai-image-pro-button-inactive" onClick={ () => onMainEditorActionButton(props.name)} >
                                    { props.name === 'core/image' &&
                                        __('Save and Replace', 'ai-image-pro')
                                    }
                                    { props.name !== 'core/image' &&
                                        __('Save and insert', 'ai-image-pro')
                                    }
                                </Button>
                                <a className="ai-image-pro-link" onClick={ closeEditorModal }>{__('Cancel', 'ai-image-pro')}</a>
                            </div>
                        </Modal>
                    ) }
                </BlockControls>
            </Fragment>
        );
    };
}, 'aiImageProControls' );
