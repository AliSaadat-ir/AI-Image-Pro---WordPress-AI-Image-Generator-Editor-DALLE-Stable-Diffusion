"use strict";

import { addFilter } from '@wordpress/hooks';
import './style.scss';
import aiImageProControls from "./components/aiImageProControls";

addFilter(
	'editor.BlockEdit',
	'ai-image-pro/controls',
	aiImageProControls,
);
