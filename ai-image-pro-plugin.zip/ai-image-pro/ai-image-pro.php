<?php

/**
 * Plugin Name:       AI Image Pro
 * Description:       AI Image Pro is your WordPress image generator and editor, powered by AI.
 * Version:           2.6.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Domain Path:       /languages
 */

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/src/admin/editor.php';
require __DIR__ . '/src/admin/user-credits.php';
require __DIR__ . '/src/admin/settings.php';
require __DIR__ . '/src/admin/admin.php';
require __DIR__ . '/src/common/attachment.php';
require __DIR__ . '/src/common/save-image.php';
require __DIR__ . '/src/common/credits.php';
require __DIR__ . '/src/integrations/openai.php';
require __DIR__ . '/src/integrations/stabilityai.php';

function aiimagepro_block_assets( $hook ) {
    $dependencies = require __DIR__ . '/gutenberg/build/index.asset.php';

    aiimagepro_add_inline_js_object();

    wp_register_style( 'aiimagepro-index', plugin_dir_url( __FILE__ ) . 'gutenberg/build/style-index.css', false, $dependencies['version'] );
    wp_enqueue_style ( 'aiimagepro-index' );
}

add_action( 'enqueue_block_assets', 'aiimagepro_block_assets' );

function aiimagepro_load_textdomain() {
    if ( ! is_admin() ) {
        return;
    }

    // get current language
    $currentLanguage = get_locale();

    if (strlen($currentLanguage) > 2) {
        $currentLanguage = explode('_', $currentLanguage)[0];
    }

    // load language regardless of locale
    load_textdomain( 'ai-image-pro', __DIR__ . "/languages/$currentLanguage.mo" );
}

function aiimagepro_init() {
    if ( ! is_admin() ) {
        return;
    }

    $dependencies = require __DIR__ . '/gutenberg/build/index.asset.php';
    wp_register_script( 'aiimagepro-index', plugin_dir_url( __FILE__ ) . 'gutenberg/build/index.js', $dependencies['dependencies'], $dependencies['version'] );
    wp_enqueue_script( 'aiimagepro-index');

    AIImagePro_Settings::instance()->init_options_if_needed();
}

add_action( 'init', 'aiimagepro_init' );

// register an uninstall hook
register_uninstall_hook( __FILE__, 'aiimagepro_uninstall' );

function aiimagepro_uninstall() {
    $setting = AIImagePro_Settings::instance();
    $setting->delete_options();
}

register_activation_hook(
	__FILE__,
	'aiimagepro_on_activation'
);

function aiimagepro_on_activation() {
    aiimagepro_set_default_settings();
}

function aiimagepro_set_default_settings () {
    AIImagePro_Settings::instance()->init_options();
}

function aiimagepro_build_plugin_js_config() {
    $settings = AIImagePro_Settings::instance();
    $nonce = wp_create_nonce('wp_rest');
    $aiImageProScriptVars = array(
        'nonce'  =>  $nonce,
        'siteUrl' => get_site_url(),
        'pluginUrl' => plugin_dir_url( __FILE__ ),
        'version' => aiimagepro_get_plugin_version(),
        'saveImageType' => $settings->get_option(AIImagePro_Settings::OPTION_PREFERRED_IMAGE_EXTENSION) == 'png' ? 'image/png' : 'image/jpeg',
        'maxHistoryItems' => intval($settings->get_option(AIImagePro_Settings::OPTION_MAX_NUMBER_OF_HISTORY_ITEMS)),
        'isOpenAIKeySet' => !empty($settings->get_option(AIImagePro_Settings::OPTION_OPENAI_API_KEY)),
        'isStabilityAIKeySet' => !empty($settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_API_KEY)),
        'settingsPageUrl' => admin_url('admin.php?page=aiimagepro_image_editor_settings'),
        'editorPageUrl' => admin_url('admin.php?page=aiimagepro'),
    );

    return $aiImageProScriptVars;
}

function aiimagepro_add_inline_js_object () {
    if ( ! is_admin() ) {
        return;
    }

    global $pagenow;

    if ($pagenow !== 'admin.php' && $pagenow !== 'post.php' && $pagenow !== 'post-new.php' && $pagenow !== 'site-editor.php') {
        return;
    }

    $version = aiimagepro_get_plugin_version();
    if ($version === false) {
        $version = rand( 1, 10000000 );
    }

    $aiimagepro_build_plugin_js_config = aiimagepro_build_plugin_js_config();

    wp_register_script( 'aiimagepro-main', plugin_dir_url( __FILE__ ) . 'assets/js/main.js', array(), $version);

    wp_add_inline_script( 'aiimagepro-main', 'var aiImagePro =' . json_encode($aiimagepro_build_plugin_js_config) );

    wp_enqueue_script( 'aiimagepro-main');
}

add_action('admin_head', 'aiimagepro_add_inline_js_object' );

function aiimagepro_get_plugin_version() {
    $plugin_data = array();
    if ( !function_exists( 'get_plugin_data' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    $plugin_data = get_plugin_data( __FILE__ );

    $plugin_version = $plugin_data['Version'] ?? false;

    return $plugin_version;
}

/**
 * TinyMCE plugin
 */

function aiimagepro_classic_buttons($buttons) {
    array_push($buttons, 'aiimagepro_classic_button_editor');

    return $buttons;
}

add_filter('mce_buttons', 'aiimagepro_classic_buttons');

function aiimagepro_classic_mce_css($mce_css) {
    if (! empty($mce_css)) {
        $mce_css .= ',';
    }
    $mce_css .= plugins_url('includes/css/classic.css', __FILE__);

    return $mce_css;
}
add_filter('mce_css', 'aiimagepro_classic_mce_css');

function aiimagepro_classic_mce_plugin($plugin_array) {
    global $pagenow;

    if ($pagenow == 'post.php' || $pagenow == 'post-new.php') {
        $plugin_array['aiimagepro_classic'] = plugins_url('assets/js/classic.js', __FILE__);
    }

    return $plugin_array;
}
add_filter('mce_external_plugins', 'aiimagepro_classic_mce_plugin');

add_action('admin_enqueue_scripts', 'aiimagepro_classic_mce_enqueue_scripts');

function aiimagepro_classic_mce_enqueue_scripts() {
    global $pagenow;

    if ($pagenow !== 'post.php' && $pagenow !== 'post-new.php' ) {
        return;
    }

    wp_enqueue_style('aiimagepro-classic-mce', plugins_url('assets/css/classic.css', __FILE__));
}

$aiImageProUserCredits = AIImagePro_User_Credits::instance(); // make sure to set up the hooks.

###['admin-notice']
