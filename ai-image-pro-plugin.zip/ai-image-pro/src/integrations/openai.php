<?php

add_action( 'rest_api_init', function () {
    register_rest_route( 'aiimagepro/openai/v1', '/generate-images', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_openai_generate_images',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));

    register_rest_route( 'aiimagepro/openai/v1', '/edit-image', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_openai_edit_image',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));

    register_rest_route( 'aiimagepro/openai/v1', '/image-variations', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_openai_generate_image_variations',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));
} );

function aiimagepro_rest_openai_generate_images ($data) {
    ###['openai-generate-images']

    $count = $data['count'] ?? 1;
    $size = $data['size'] ?? 'small';
    $prompt = $data['prompt'] ?? '';
    $model = $data['model'] ?? 'dall-e-2';
    $imageQuality = $data['imageQuality'] === 'standard' ? 'standard' : 'hd';
    $imageStyle = $data['imageStyle'] ?? 'natural';

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, $count, 'dalle')) {
        aiimagepro_update_user_credit($user->ID, -1 * $count, 'dalle');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    if ( empty( $prompt ) ) {
        return new WP_Error( 'missing_param', 'Missing prompt parameter', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $dimensions = '256x256';
    if ($size == 'medium') {
        $dimensions = '512x512';
    } else if ($size == 'large') {
        $dimensions = '1024x1024';
    } else if ($size == 'xlarge-1792x1024') {
        $dimensions = '1792x1024';
    } else if ($size == 'xlarge-1024x1792') {
        $dimensions = '1024x1792';
    }

    $settings = AIImagePro_Settings::instance();

    try {
        $requestBody = [
            'prompt'      => $prompt,
            'n'          => intval($count),
            'size' => $dimensions,
            'response_format' => 'url',
            'model' => $model,
        ];

        if ($model === 'dall-e-3') {
            $requestBody['quality'] = $imageQuality;
            $requestBody['style'] = $imageStyle;
        }

        $imageResponse = $client->request( 'POST', 'https://api.openai.com/v1/images/generations', [
            'body'    => json_encode($requestBody),
            'headers' => [
                'Authorization' => 'Bearer ' . $settings->get_option(AIImagePro_Settings::OPTION_OPENAI_API_KEY),
                'Content-Type'  => 'application/json',
            ],
        ] );

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {
        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $imageResponse->getBody();
    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_file_by_url($image['url'], $dimensions, $prompt);
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response(aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);
}

/**
 * @param WP_REST_Request $data
 * @return WP_Error|WP_REST_Response
 */
function aiimagepro_rest_openai_edit_image ($data)
{
    ###['openai-edit-image']

    $count = $data['count'] ?? 1;
    $size = $data['size'] ?? 'small';
    $prompt = $data['prompt'] ?? '';

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, $count, 'dalle')) {
        aiimagepro_update_user_credit($user->ID, -1 * $count, 'dalle');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    $files = $data->get_file_params();
    $mask = $files['mask'] ?? null;
    $image = $files['image'] ?? null;

    if ( empty( $prompt ) ) {
        return new WP_Error( 'missing_param', 'Missing prompt parameter', array( 'status' => 400 ) );
    }

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    if ( empty( $mask ) ) {
        return new WP_Error( 'missing_param', 'Missing mask parameter', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $dimensions = '256x256';
    if ($size == 'medium') {
        $dimensions = '512x512';
    } else if ($size == 'large') {
        $dimensions = '1024x1024';
    }

    $settings = AIImagePro_Settings::instance();
    try {
        // multipart/form-data request
        $response = $client->request('POST', 'https://api.openai.com/v1/images/edits', [
            'headers' => [
                'Authorization' => 'Bearer ' . $settings->get_option(AIImagePro_Settings::OPTION_OPENAI_API_KEY),
            ],
            'multipart' => [
                [
                    'name'     => 'prompt',
                    'contents' => $prompt
                ],
                [
                    'name'     => 'image',
                    'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($image['tmp_name'], 'r'), //fopen($image['tmp_name'], 'r'),
                    'filename' => 'image.png',
                    'headers'  => [
                        'Content-Type' => 'image/png',
                    ],
                ],
                [
                    'name'     => 'mask',
                    'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($mask['tmp_name'], 'r'), //fopen($mask['tmp_name'], 'r'),
                    'filename' => 'mask.png',
                    'headers'  => [
                        'Content-Type' => 'image/png',
                    ],
                ],
                [
                    'name'     => 'n',
                    'contents' => $count,
                ],
                [
                    'name'     => 'size',
                    'contents' => $dimensions,
                ],
                [
                    'name'     => 'response_format',
                    'contents' => 'url',
                ],
            ],

        ]);

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {

        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $response->getBody();
    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_file_by_url($image['url'], $dimensions, $prompt);
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response( aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);

}

function aiimagepro_rest_openai_generate_image_variations ($data)
{
    ###['openai-generate-image-variations']

    $count = $data['count'] ?? 1;
    $size = $data['size'] ?? 'small';

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, $count, 'dalle')) {
        aiimagepro_update_user_credit($user->ID, -1 * $count, 'dalle');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    $files = $data->get_file_params();
    $image = $files['image'] ?? null;

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $dimensions = '256x256';
    if ($size == 'medium') {
        $dimensions = '512x512';
    } else if ($size == 'large') {
        $dimensions = '1024x1024';
    }

    $settings = AIImagePro_Settings::instance();
    try {
        // multipart/form-data request
        $response = $client->request('POST', 'https://api.openai.com/v1/images/variations', [
            'headers' => [
                'Authorization' => 'Bearer ' . $settings->get_option(AIImagePro_Settings::OPTION_OPENAI_API_KEY),
            ],
            'multipart' => [
                [
                    'name'     => 'image',
                    'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($image['tmp_name'], 'r'), //fopen($image['tmp_name'], 'r'),
                    'filename' => 'image.png',
                    'headers'  => [
                        'Content-Type' => 'image/png',
                    ],
                ],
                [
                    'name'     => 'n',
                    'contents' => $count,
                ],
                [
                    'name'     => 'size',
                    'contents' => $dimensions,
                ],
                [
                    'name'     => 'response_format',
                    'contents' => 'url',
                ],
            ],

        ]);

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {
        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, $count, 'dalle');
        return new WP_Error( 'openai_error', json_encode([
            'message' => 'error while calling openai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $response->getBody();
    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_file_by_url($image['url'], $dimensions, 'variation-' . rand(0, 1000000) );
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response(aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);

}

function aiimagepro_upload_file_by_url( $image_url, $dimensions, $imagePrompt) {

    $imagePromptWithOnlyLetters = preg_replace('/[^A-Za-z0-9\- ]/', '', $imagePrompt);
    $imagePromptWithOnlyLetters = str_replace(' ', '-', $imagePromptWithOnlyLetters);
    $imagePromptWithOnlyLetters = substr($imagePromptWithOnlyLetters, 0, 40);
    $imagePromptWithOnlyLetters = strtolower($imagePromptWithOnlyLetters);

    // it allows us to use download_url() and wp_handle_sideload() functions
    require_once( ABSPATH . 'wp-admin/includes/file.php' );

    // download to temp dir
    $temp_file = download_url( $image_url );

    // add extension to temp file (get it from mime type)
    $mime_type = mime_content_type( $temp_file );
    $extension = explode( '/', $mime_type )[1];

    $newFilename = $imagePromptWithOnlyLetters . '-' . $dimensions . '-' . rand( 0, 99999999 ) . '.' . $extension;

    rename ( $temp_file, $newFilename );
    $temp_file = $newFilename;

    if( is_wp_error( $temp_file ) ) {
        return false;
    }

    // move the temp file into the uploads directory
    $file = array(
        'name'     => basename( $temp_file ),
        'type'     => mime_content_type( $temp_file ),
        'tmp_name' => $temp_file,
        'size'     => filesize( $temp_file ),
    );

    $sideload = wp_handle_sideload(
        $file,
        array(
            'test_form'   => false // no needs to check 'action' parameter
        )
    );

    if( ! empty( $sideload[ 'error' ] ) ) {
        // you may return error message if you want
        return false;
    }

    // it is time to add our uploaded image into WordPress media library
    $attachment_id = wp_insert_attachment(
        array(
            'guid'           => $sideload[ 'url' ],
            'post_mime_type' => $sideload[ 'type' ],
            'post_title'     => basename( $sideload[ 'file' ] ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ),
        $sideload[ 'file' ]
    );

    if( is_wp_error( $attachment_id ) || ! $attachment_id ) {
        return false;
    }

    // update medatata, regenerate image sizes
    require_once( ABSPATH . 'wp-admin/includes/image.php' );

    wp_update_attachment_metadata(
        $attachment_id,
        wp_generate_attachment_metadata( $attachment_id, $sideload[ 'file' ] )
    );

    return [
        'id' => $attachment_id,
        'url' => wp_get_attachment_image_url($attachment_id, explode('x', $dimensions))
    ];
}
