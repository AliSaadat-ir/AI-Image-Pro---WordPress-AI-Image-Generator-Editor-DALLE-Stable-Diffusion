<?php

add_action( 'rest_api_init', function () {
    register_rest_route( 'aiimagepro/stability-ai/v1', '/generate-images', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_stability_ai_generate_images',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));

    register_rest_route( 'aiimagepro/stability-ai/v1', '/edit-image', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_stability_ai_edit_image',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));

    register_rest_route( 'aiimagepro/stability-ai/v1', '/upscale-image', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_rest_stability_ai_upscale_image',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));
} );

function aiimagepro_rest_stability_ai_generate_images ($data) {

    ###['stabilityai-generate-images']

    $imageCount = intval($data['imageCount']) ?? 1;
    $prompt = $data['prompt'] ?? '';
    $width = intval($data['width']) ?? 256;
    $height = intval($data['height']) ?? 256;
    $engine = $data['engine'];
    $sampler = $data['sampler'];
    $steps = intval($data['steps']) ?? 30;
    $cfg = intval($data['cfg']) ?? 7;
    $seed = intval($data['seed']) ?? 0;
    $style = $data['style'] ?? '';

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, $imageCount, 'stable_diffusion')) {
        aiimagepro_update_user_credit($user->ID, -1 * $imageCount, 'stable_diffusion');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    if ( empty( $prompt ) ) {
        return new WP_Error( 'missing_param', 'Missing prompt parameter', array( 'status' => 400 ) );
    }

    if ( empty( $engine ) ) {
        return new WP_Error( 'missing_param', 'Missing engine parameter', array( 'status' => 400 ) );
    }

    if ( empty( $sampler ) ) {
        return new WP_Error( 'missing_param', 'Missing sampler parameter', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $settings = AIImagePro_Settings::instance();
    try {

        $body = [
            'samples' => $imageCount,
            'width' => $width,
            'height' => $height,
            'sampler' => $sampler,
            'steps' => $steps,
            'cfg_scale' => $cfg,
            'seed' => $seed,
            'text_prompts' => [
                [
                    'text' => $prompt,
                    'weight' => 1,
                ],
            ]
        ];

        if ($style) {
            $body['style_preset'] = $style;
        }

        $imageResponse = $client->request( 'POST', 'https://api.stability.ai/v1/generation/' . $engine . '/text-to-image', [
            'body'    => json_encode( $body ),
            'headers' => [
                'Authorization' => $settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_API_KEY),
                'Content-Type'  => 'application/json',
            ],
        ] );

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {
        aiimagepro_update_user_credit($user->ID, $imageCount, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, $imageCount, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $imageResponse->getBody();
    $json = json_decode($body, true);
    $data = $json['artifacts'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_base64_image($image['base64'], $prompt);
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response(aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);
}

function aiimagepro_rest_stability_ai_upscale_image ($data) {

    ###['stabilityai-upscale-image']
    $engine = 'esrgan-v1-x2plus';

    $what = $data['what'] == 'width' ? 'width' : 'height';
    $amount = intval($data['amount']) ?? 512;

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, 1, 'stable_diffusion')) {
        aiimagepro_update_user_credit($user->ID, -1, 'stable_diffusion');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    $files = $data->get_file_params();
    $image = $files['image'] ?? null;

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    // if there is an error uploading the image, return it
    if ( ! empty( $image['error'] ) ) {
        return new WP_Error( 'upload_error', 'There is an error uploading the image. Please make sure maximum upload size is sufficient (25MB+)', array( 'status' => 400 ) );
    }

    $imageDimensions = getimagesize($image['tmp_name']);
    $width = $imageDimensions[0] ?? 512;
    $height = $imageDimensions[1] ?? 512;
    if ($width * $height > 1024 * 1024) {
        return new WP_Error( 'image_too_big', 'Image is too large. Maximum size for image to be upscaled is 1024x1024 (1048576 pixels)', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $settings = AIImagePro_Settings::instance();
    try {
        // multipart/form-data request
        $response = $client->request('POST', 'https://api.stability.ai/v1/generation/' . $engine . '/image-to-image/upscale', [
            'headers' => [
                'Authorization' => $settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_API_KEY),
            ],
            'multipart' => [
                [
                    'name'     => 'image',
                    'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($image['tmp_name'], 'r'),
                    'filename' => 'image.png',
                    'headers'  => [
                        'Content-Type' => 'image/png',
                    ],
                ],
                [
                    'name'    => $what,
                    'contents' => $amount,
                ],
            ],

        ]);

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {
        aiimagepro_update_user_credit($user->ID, 1, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, 1, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $response->getBody();
    $json = json_decode($body, true);
    $data = $json['artifacts'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_base64_image($image['base64'], rand(0, 99999999));
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response(aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);
}

/**
 * @param WP_REST_Request $data
 * @return WP_Error|WP_REST_Response
 */
function aiimagepro_rest_stability_ai_edit_image ($data)
{
    ###['stabilityai-edit-image']

    $imageCount = intval($data['imageCount']) ?? 1;
    $prompt = $data['prompt'] ?? '';
    $engine = $data['engine'];
    $sampler = $data['sampler'];
    $steps = intval($data['steps']) ?? 30;
    $cfg = intval($data['cfg']) ?? 7;
    $seed = intval($data['seed']) ?? 0;
    $style = $data['style'] ?? '';

    $user = wp_get_current_user();
    if (aiimagepro_user_has_credit($user->ID, $imageCount, 'stable_diffusion')) {
        aiimagepro_update_user_credit($user->ID, -1 * $imageCount, 'stable_diffusion');
    } else {
        return new WP_Error( 'no_credit', 'You do not have enough credits to generate this many images', array( 'status' => 400 ) );
    }

    $files = $data->get_file_params();
    $mask = $files['mask'] ?? null;
    $image = $files['image'] ?? null;

    if ( empty( $prompt ) ) {
        return new WP_Error( 'missing_param', 'Missing prompt parameter', array( 'status' => 400 ) );
    }

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    if ( empty( $mask ) ) {
        return new WP_Error( 'missing_param', 'Missing mask parameter', array( 'status' => 400 ) );
    }

    $client = new \AIImagePro\Dependencies\GuzzleHttp\Client();

    $settings = AIImagePro_Settings::instance();
    try {

        $multipart = [
            [
                'name'     => 'mask_source',
                'contents' => 'MASK_IMAGE_BLACK',
            ],
            [
                'name'     => 'init_image',
                'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($image['tmp_name'], 'r'),
                'filename' => 'image.png',
                'headers'  => [
                    'Content-Type' => 'image/png',
                ],
            ],
            [
                'name'     => 'mask_image',
                'contents' => \AIImagePro\Dependencies\GuzzleHttp\Psr7\Utils::tryFopen($mask['tmp_name'], 'r'),
                'filename' => 'mask.png',
                'headers'  => [
                    'Content-Type' => 'image/png',
                ],
            ],
            [
                'name'     => 'text_prompts[0][text]',
                'contents' => $prompt,
            ],
            [
                'name'     => 'text_prompts[0][weight]',
                'contents' => 1,
            ],
            [
                'name'    => 'sampler',
                'contents' => $sampler,
            ],
            [
                'name'    => 'steps',
                'contents' => $steps,
            ],
            [
                'name'    => 'cfg_scale',
                'contents' => $cfg,
            ],
            [
                'name'    => 'seed',
                'contents' => $seed,
            ],
            [
                'name'    => 'samples',
                'contents' => $imageCount,
            ]
        ];

        if ($style) {
            $multipart[] = [
                'name'    => 'style_preset',
                'contents' => $style,
            ];
        }

        // multipart/form-data request
        $response = $client->request('POST', 'https://api.stability.ai/v1/generation/' . $engine . '/image-to-image/masking', [
            'headers' => [
                'Authorization' => $settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_API_KEY),
            ],
            'multipart' => $multipart,

        ]);

    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\ClientException $e) {
        aiimagepro_update_user_credit($user->ID, $imageCount, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getResponse()->getBody()->getContents(),
        ]), array( 'status' => 500 ) );
    } catch (\AIImagePro\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
        aiimagepro_update_user_credit($user->ID, $imageCount, 'stable_diffusion');
        return new WP_Error( 'stability_ai_error', json_encode([
            'message' => 'error while calling stability ai',
            'responseBody' => $e->getMessage(),
        ]), array( 'status' => 500 ) );
    }

    $body = $response->getBody();
    $json = json_decode($body, true);
    $data = $json['artifacts'] ?? [];

    $images = array();
    foreach ($data as $image) {
        $imageUrl = aiimagepro_upload_base64_image($image['base64'], $prompt);
        if ($imageUrl) {
            $images[] = $imageUrl;
        }
    }

    return new WP_REST_Response(aiimagepro_include_user_credits([
        'images' => $images,
    ]), 200);

}

function aiimagepro_upload_base64_image( $base64_image, $imagePrompt) {

    $imagePromptWithOnlyLetters = preg_replace('/[^A-Za-z0-9\- ]/', '', $imagePrompt);
    $imagePromptWithOnlyLetters = str_replace(' ', '-', $imagePromptWithOnlyLetters);
    $imagePromptWithOnlyLetters = substr($imagePromptWithOnlyLetters, 0, 40);
    $imagePromptWithOnlyLetters = strtolower($imagePromptWithOnlyLetters);

    // it allows us to use download_url() and wp_handle_sideload() functions
    require_once( ABSPATH . 'wp-admin/includes/file.php' );

    // save base64 image to temp file
    $temp_file = tempnam(sys_get_temp_dir(), 'ai-image-pro');
    file_put_contents($temp_file, base64_decode($base64_image));

    // add extension to temp file (get it from mime type)
    $mime_type = mime_content_type( $temp_file );
    $extension = explode( '/', $mime_type )[1];

    $newFilename = $imagePromptWithOnlyLetters . '-' . rand( 0, 99999999 ) . '.' . $extension;

    rename ( $temp_file, $newFilename );
    $temp_file = $newFilename;

    if( is_wp_error( $temp_file ) ) {
        return false;
    }

    $imageDimensions = getimagesize($temp_file);
    $width = $imageDimensions[0] ?? 512;
    $height = $imageDimensions[1] ?? 512;

    // move the temp file into the uploads directory
    $file = array(
        'name'     => basename( $temp_file ),
        'type'     => mime_content_type( $temp_file ),
        'tmp_name' => $temp_file,
        'size'     => filesize( $temp_file ),
    );

    $sideload = wp_handle_sideload(
        $file,
        array(
            'test_form'   => false // no needs to check 'action' parameter
        )
    );

    if( ! empty( $sideload[ 'error' ] ) ) {
        // you may return error message if you want
        return false;
    }

    // it is time to add our uploaded image into WordPress media library
    $attachment_id = wp_insert_attachment(
        array(
            'guid'           => $sideload[ 'url' ],
            'post_mime_type' => $sideload[ 'type' ],
            'post_title'     => basename( $sideload[ 'file' ] ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ),
        $sideload[ 'file' ]
    );

    if( is_wp_error( $attachment_id ) || ! $attachment_id ) {
        return false;
    }

    // update medatata, regenerate image sizes
    require_once( ABSPATH . 'wp-admin/includes/image.php' );

    wp_update_attachment_metadata(
        $attachment_id,
        wp_generate_attachment_metadata( $attachment_id, $sideload[ 'file' ] )
    );

    return [
        'id' => $attachment_id,
        'url' => wp_get_attachment_image_url($attachment_id, array($width, $height)),
    ];
}
