<?php

add_action( 'rest_api_init', function () {
    register_rest_route( 'aiimagepro', '/get-attachment', array(
        'methods' => 'GET',
        'callback' => 'aiimagepro_get_attachment',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));
} );


function aiimagepro_get_attachment ($data) {
    $attachment_id = $data->get_param('id');

    if ( empty( $attachment_id ) ) {
        return new WP_Error( 'missing_param', 'Missing id parameter', array( 'status' => 400 ) );
    }

    $attachment = get_post( $attachment_id );

    if ( empty( $attachment ) ) {
        return new WP_Error( 'not_found', 'Attachment not found', array( 'status' => 404 ) );
    }

    $image_url = wp_get_attachment_url( $attachment_id );

    $image_type = wp_check_filetype( $image_url );
    if ( ! in_array( $image_type['ext'], ['jpg', 'jpeg', 'png'] ) ) {
        return new WP_Error( 'not_an_image', 'Attachment not found', array( 'status' => 404 ) );
    }

    return new WP_REST_Response([
        'id' => $attachment_id,
        'url' => $image_url,
    ], 200);
}
