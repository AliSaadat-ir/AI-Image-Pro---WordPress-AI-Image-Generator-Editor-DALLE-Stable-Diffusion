<?php

add_action( 'rest_api_init', function () {
    register_rest_route( 'aiimagepro', '/save-image', array(
        'methods' => 'POST',
        'callback' => 'aiimagepro_save_image',
        'permission_callback' => function () {
            return is_user_logged_in() && current_user_can( 'edit_posts' );
        }
    ));
} );


function aiimagepro_save_image ($data) {
    // save image in the media library
    $files = $data->get_file_params();
    $image = $files['image'] ?? null;

    $imageType = $data->get_param('imageType');

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    if ( empty( $image ) ) {
        return new WP_Error( 'missing_param', 'Missing image parameter', array( 'status' => 400 ) );
    }

    try {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $extension = $imageType === 'image/jpeg' ? 'jpg' : 'png';

        // rename the file to add extension (required by media_handle_sideload)
        $image['name'] = $image['name'] . '.' . $extension;
        rename ( $image['tmp_name'], $image['tmp_name'] . '.' . $extension );
        $image['tmp_name'] = $image['tmp_name'] . '.' . $extension;

        $image_id = media_handle_sideload( $image, 0 );

        $imageFileSizeInMB = filesize( get_attached_file( $image_id ) ) / 1024 / 1024;
    }
    catch (\Throwable $e) {
        return new WP_Error( 'upload_error', 'Error uploading image (exception)', array( 'status' => 400 ) );
    }

    if ( is_wp_error( $image_id ) ) {
        return new WP_Error( 'upload_error', 'Error uploading image', array( 'status' => 400 ) );
    }

    $image_url = wp_get_attachment_url( $image_id );

    return new WP_REST_Response([
        'id' => $image_id,
        'url' => $image_url,
        'fileSizeInMB' => $imageFileSizeInMB,
    ], 200);
}
