<?php

function aiimagepro_user_has_credit ($user_id, $image_count, $type='dalle') {

    // if admin, return true
    if (current_user_can('manage_options')) {
        return true;
    }

    if ($type == 'dalle') {
        $credit = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);
    } else if ($type == 'stable_diffusion') {
        $credit = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true);
    }

    if (empty($credit)) {
        $credit = 0;
    }

    return $credit >= $image_count;
}

function aiimagepro_update_user_credit ($user_id, $update_amount, $type='dalle') {

    // if admin
    if (current_user_can('manage_options')) {
        return;
    }

    if ($type == 'dalle') {
        $current_credit = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);

        if (empty($current_credit)) {
            $current_credit = 0;
        }

        $credit = $current_credit + $update_amount;

        update_user_meta($user_id, 'ai_image_pro_dalle_credits', $credit);
    } else if ($type == 'stable_diffusion') {
        $current_credit = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true);

        if (empty($current_credit)) {
            $current_credit = 0;
        }

        $credit = $current_credit + $update_amount;

        update_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', $credit);
    }
}

function aiimagepro_include_user_credits ($response) {
    $user_id = get_current_user_id();
    $dalle_credit = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);
    $dalle_credit = empty($dalle_credit) ? 0 : $dalle_credit;
    $stable_diffusion_credit = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true);
    $stable_diffusion_credit = empty($stable_diffusion_credit) ? 0 : $stable_diffusion_credit;

    $response['credits'] = [
        'dalle' => $dalle_credit,
        'stable_diffusion' => $stable_diffusion_credit
    ];

    return $response;
}
