<?php

class AIImagePro_Admin {
    /**
     * The single instance of the class.
     *
     * @var AIImagePro_Admin
     */
    protected static $_instance = null;

    protected ?AIImagePro_Editor $editor = null;

    protected ?AIImagePro_Settings $settings = null;

    protected ?AIImagePro_User_Credits $user_credits = null;

    /**
     * Main AIImagePro_Admin Instance.
     *
     * Ensures only one instance of AIImagePro_Admin is loaded or can be loaded.
     *
     * @static
     * @return AIImagePro_Admin - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * AIImagePro_Admin Constructor.
     */
    public function __construct() {
        $this->editor = new AIImagePro_Editor();
        $this->settings = new AIImagePro_Settings();
        $this->user_credits = AIImagePro_User_Credits::instance();
        $this->init();
    }

    /**
     * Initialize class
     */
    public function init() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this->editor, 'enqueue_scripts' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'admin_enqueue_scripts', array( $this->user_credits, 'enqueue_scripts' ) );
        add_action( 'admin_notices' , array( $this->settings, 'admin_config_notice' ) );
    }

    /**
     * Add options page.
     */
    public function admin_menu() {

        ###['admin-menu']

        add_menu_page(
            esc_html__('AI Image Pro Settings', 'ai-image-pro'),
            esc_html__('AI Image Pro', 'ai-image-pro'),
            'edit_posts',
            'aiimagepro',
            array( $this->editor, 'render' ),
            'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjwhLS0gQ3JlYXRlZCB3aXRoIFZlY3Rvcm5hdG9yIChodHRwOi8vdmVjdG9ybmF0b3IuaW8vKSAtLT4KPHN2ZyBoZWlnaHQ9IjEwMCUiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3R5bGU9ImZpbGwtcnVsZTpub256ZXJvO2NsaXAtcnVsZTpldmVub2RkO3N0cm9rZS1saW5lY2FwOnJvdW5kO3N0cm9rZS1saW5lam9pbjpyb3VuZDsiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDI0MCAyNDAiIHdpZHRoPSIxMDAlIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnZlY3Rvcm5hdG9yPSJodHRwOi8vdmVjdG9ybmF0b3IuaW8iIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4KPGRlZnMvPgo8ZyBpZD0iVW50aXRsZWQiIHZlY3Rvcm5hdG9yOmxheWVyTmFtZT0iVW50aXRsZWQiPgo8cGF0aCBkPSJNNTYuNDMyIDIzMi4yODFDNjUuNjA4IDIwNC43OTkgNzQuMzUxIDE4Ny4xMDIgODIuNzI5IDE3Ni4yNTRDODguODIzIDE4MS4yMSA5Ni4wODMgMTg0Ljk3MiAxMDQuMTczIDE4Ny4xMjVDMTA0LjE3NyAxODcuMTI0IDEwNC4xNzkgMTg3LjEyNSAxMDQuMTg0IDE4Ny4xMjRDMTA4LjMzNSAxODguMjMgMTEyLjY0OSAxODguODg3IDExNi45OSAxODkuMDc0QzEyMi41MzkgMTg5LjMxMiAxMjcuNjk0IDE4OS4wMDYgMTMyLjQ5NSAxODguMTc5QzEzMy44MzIgMTk4Ljc0NSAxMzIuOTc5IDIxMy4yNCAxMjkuMTIgMjMzLjAzNUwxNzMuOTkxIDIzMy4wMzVDMjAzLjkzMiAyMzMuMDM1IDIyOC4yNCAyMDguNzI3IDIyOC4yNCAxNzguNzg2TDIyOC4yNCA3MC4yODZDMjI4LjI0IDQwLjM0NSAyMDMuOTMyIDE2LjAzNyAxNzMuOTkxIDE2LjAzN0w2NS40OTEgMTYuMDM3QzM1LjU1IDE2LjAzNyAxMS4yNDIgNDAuMzQ1IDExLjI0MiA3MC4yODZMMTEuMjQyIDE3OC43ODZDMTEuMjQyIDIwNS42NCAzMC43OTYgMjI3Ljk2MyA1Ni40MzIgMjMyLjI4MVpNMTE4Ljk3OCAxNzguODg1QzEyOC41MDggMTc5LjI5NiAxMzYuNjY0IDE3OC4xMzggMTQzLjc0MSAxNzUuMzU2QzE0NS4zOTUgMTc0LjcwNiAxNDYuOTkgMTczLjk2NyAxNDguNTI5IDE3My4xMzlDMTUzLjYxMiAxNzAuNDA0IDE1OC4xODEgMTY2LjYyOCAxNjIuMTEzIDE2MS45MTNDMTc3LjMzNiAxNDMuNjUzIDE2OS4zMzcgMTI0LjI0NSAxNjIuMjc5IDEwNy4xMkMxNTMuNDk0IDg1LjgwNSAxNDkuMDI5IDcxLjk2MiAxNjcuMTMgNTYuNTk2QzE3MC40NDUgNTMuNzgxIDE3MS4yNyA0OC45OTggMTY5LjA4NyA0NS4yMzZDMTY2LjkwNCA0MS40NzUgMTYyLjM0MSAzOS44MTcgMTU4LjI1MyA0MS4yOTlDMTQ1LjkwNCA0NS43NzUgMTM0LjU4MSA1MC43NyAxMjQuNTk2IDU2LjE0M0MxMjQuNTk0IDU2LjE0NCAxMjQuNTkyIDU2LjE0NSAxMjQuNTg5IDU2LjE0NkMxMDIuODEzIDY3Ljg2NiA4Ni45OTIgODEuNDk3IDc3LjU2OSA5Ni42NTlDNjguOTIxIDExMC41NzIgNjYuMDM0IDEyNS4yNzQgNjkuMjIgMTM5LjE3NkM3MC45NzQgMTQ2LjgzMSA3NC41MzIgMTUzLjc4IDc5LjQyMyAxNTkuNjVDODguODAyIDE3MC45MDkgMTAzLjA4NiAxNzguMiAxMTguOTc4IDE3OC44ODVaIiBmaWxsPSIjMDAwMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIG9wYWNpdHk9IjEiIHN0cm9rZT0ibm9uZSIgdmVjdG9ybmF0b3I6bGF5ZXJOYW1lPSJwYXRoIi8+CjwvZz4KPC9zdmc+Cg=='
        );

        add_submenu_page(
            'aiimagepro',
            esc_html__('AI Image Pro', 'ai-image-pro'),
            esc_html__('AI Image Pro Editor', 'ai-image-pro'),
            'edit_posts',
            'aiimagepro',
            array( $this->editor, 'render' )
        );

        add_submenu_page(
            'aiimagepro',
            esc_html__('AI Image Pro Settings', 'ai-image-pro'),
            esc_html__('Settings', 'ai-image-pro'),
            'manage_options',
            'aiimagepro_image_editor_settings',
            array( $this->settings, 'render' )
        );

        add_submenu_page(
            'aiimagepro',
            esc_html__('AI Image Pro Users', 'ai-image-pro'),
            esc_html__('Users & Credit', 'ai-image-pro'),
            'manage_options',
            'aiimagepro_users',
            array( $this->user_credits, 'render' )
        );
    }

    public function enqueue_scripts()
    {
        $version = aiimagepro_get_plugin_version();
        if ($version === false) {
            $version = rand( 1, 10000000 );
        }

        wp_enqueue_style( 'aiimagepro-admin', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/admin.css', array(), $version );
    }

    public function register_settings()
    {
        $this->settings->register_settings();
    }
}


$aiimagepro_admin = AIImagePro_Admin::instance();

add_action('admin_init', array ($aiimagepro_admin, 'register_settings'));
