<?php

class AIImagePro_User_Credits
{
    // singleton instance
    private static $instance;

    // singleton constructor
    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function __construct()
    {
        add_action('admin_init', array($this, 'process_update_credit'));

        add_action('ai_image_pro_increase_user_credit', array($this, 'increase_user_credit'));
        add_action('ai_image_pro_set_user_credit', array($this, 'set_user_credit'));
    }

    public function render()
    {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

            <?php if (isset($_GET['user_id']) && isset($_GET['action']) && $_GET['action'] === 'edit_credit') {
                ?>
                <p>
                    <?php echo sprintf(esc_html__('User credits are stored in the user meta fields %s and %s.', 'ai-image-pro'), '<code>ai_image_pro_dalle_credits</code>', '<code>ai_image_pro_stable_diffusion_credits</code>'); ?>
                    <?php echo esc_html__('You can edit the credits of the user below. 1 credit equals to 1 image edit/generation.', 'ai-image-pro'); ?>
                </p>
                <?php
                $this->display_edit_credit();
            } else {
                ?>
                <p><?php echo sprintf(esc_html__('This page allows you to view and edit the credits of users. User credits are stored in the user meta fields %s and %s.', 'ai-image-pro'), '<code>ai_image_pro_dalle_credits</code>', '<code>ai_image_pro_stable_diffusion_credits</code>'); ?></p>
                <?php $this->display_user_table(); ?>
             <?php } ?>
        </div>
        <?php
    }

    function display_user_table() {
        $search_name = isset($_GET['search_name']) ? sanitize_text_field($_GET['search_name']) : '';

        $number_per_page = 25;
        $user_query = new WP_User_Query(array(
            'number' => $number_per_page,
            'paged' => isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1, // Current page number
            'search' => '*' . $search_name . '*',
        ));

        $users = $user_query->get_results();

        if (empty($users)) {
            ?>
            <div class="pt-2">
                <p><?php esc_html_e('No users found.', 'ai-image-pro'); ?></p>
            </div>
            <?php
            return;
        }
        ?>
        <div class="container ps-0">
            <form method="get" action="">
                <input type="hidden" name="page" value="aiimagepro_users">
                <div class="input-group w-25 float-end">
                    <input type="text" name="search_name" id="search_name" class="form-control" placeholder="<?php esc_attr_e('Search by Name', 'ai-image-pro'); ?>" value="<?php echo $search_name; ?>">
                    <button class="btn btn-outline-secondary" type="submit"><?php esc_html_e('Search', 'ai-image-pro'); ?></button>
                </div>
            </form>

            <table class="table">
                <thead>
                <tr>
                    <th><?php esc_html_e('ID', 'ai-image-pro'); ?></th>
                    <th><?php esc_html_e('Username', 'ai-image-pro'); ?></th>
                    <th><?php esc_html_e('Dalle Credit', 'ai-image-pro'); ?></th>
                    <th><?php esc_html_e('Stable Diffusion Credit', 'ai-image-pro'); ?></th>
                    <th><?php esc_html_e('Actions', 'ai-image-pro'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($users as $user) {
                    $user_id = $user->ID;
                    $dalle_credit = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);
                    $dalle_credit = empty($dalle_credit) ? esc_html__('-', 'ai-image-pro') : $dalle_credit;
                    $stable_diffusion_credit = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true) ?? 0;
                    $stable_diffusion_credit = empty($stable_diffusion_credit) ? esc_html__('-', 'ai-image-pro') : $stable_diffusion_credit;
                    ?>
                    <tr>
                        <td><?php echo $user_id; ?></td>
                        <td><?php echo $user->user_login; ?></td>
                        <td><?php echo $dalle_credit; ?></td>
                        <td><?php echo $stable_diffusion_credit; ?></td>
                        <td><a href="<?php echo esc_url(add_query_arg(array('user_id' => $user_id, 'action' => 'edit_credit'))); ?>">Edit Credit</a></td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </div>
        <?php

        $total_users = $user_query->get_total();
        $total_pages = ceil($total_users / $number_per_page);

        if ($total_pages > 1) {
            $current_page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
            echo '<div class="container pagination">';
            echo '<ul class="pagination">';
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<li class="page-item';
                if ($current_page === $i) {
                    echo ' active';
                }
                echo '"><a class="page-link" href="' . esc_url(add_query_arg('paged', $i)) . '">' . $i . '</a></li>';
            }
            echo '</ul>';
            echo '</div>';
        }
    }

    function display_edit_credit() {
        if (isset($_GET['user_id']) && isset($_GET['action']) && $_GET['action'] === 'edit_credit') {
            $user_id = intval($_GET['user_id']);
            $dalle_credit = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);
            $dalle_credit = empty($dalle_credit) ? 0 : $dalle_credit;
            $stable_diffusion_credit = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true);
            $stable_diffusion_credit = empty($stable_diffusion_credit) ? 0 : $stable_diffusion_credit;

            $user = get_user_by('id', $user_id);

            if (!$user) {
                ?>
                <div class="pt-2">
                    <p><?php esc_html_e('User not found.', 'ai-image-pro'); ?></p>
                </div>
                <?php
                return;
            }

            ?>
            <div class="container ps-0 pt-3">
                <h5><?php esc_html_e('User Information', 'ai-image-pro'); ?></h5>
                <table class="table">
                    <tbody>
                    <tr>
                        <td><?php esc_html_e('ID', 'ai-image-pro'); ?></td>
                        <td><?php echo $user_id; ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e('Username', 'ai-image-pro'); ?></td>
                        <td><?php echo $user->user_login; ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="container ps-0 pt-3">
                <h5><?php esc_html_e('Edit Credit', 'ai-image-pro'); ?></h5>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="ai_image_pro_dalle_credits"><?php esc_html_e('Dalle Credit', 'ai-image-pro'); ?>:</label>
                        <input type="number" name="ai_image_pro_dalle_credits" id="ai_image_pro_dalle_credits" class="form-control" value="<?php echo esc_attr($dalle_credit); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="ai_image_pro_stable_diffusion_credits"><?php esc_html_e('Stable Diffusion Credit', 'ai-image-pro'); ?>:</label>
                        <input type="number" name="ai_image_pro_stable_diffusion_credits" id="ai_image_pro_stable_diffusion_credits" class="form-control" value="<?php echo esc_attr($stable_diffusion_credit); ?>" />
                    </div>
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" />
                    <button type="submit" name="update_credit" class="btn btn-primary mt-3"><?php esc_html_e('Update Credit', 'ai-image-pro'); ?></button>

                    <a href="<?php echo esc_url(add_query_arg(array('page' => 'aiimagepro_users', 'action' => 'users_table'))); ?>" class="btn btn-outline-secondary mt-3"><?php esc_html_e('Back', 'ai-image-pro'); ?></a>
                </form>
            </div>
            <?php
        }
    }

    public function process_update_credit() {
        if (isset($_POST['update_credit'])) {
            $user_id = intval($_POST['user_id']);
            $dalle_credit = intval($_POST['ai_image_pro_dalle_credits']);
            $stable_diffusion_credit = intval($_POST['ai_image_pro_stable_diffusion_credits']);

            update_user_meta($user_id, 'ai_image_pro_dalle_credits', $dalle_credit);
            update_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', $stable_diffusion_credit);

            // redirect to the users table
            wp_redirect(esc_url(add_query_arg(array('page' => 'aiimagepro_users', 'action' => 'users_table'))));
            exit;
        }
    }

    public function increase_user_credit($args) {
        $user_id = intval($args['user_id']);
        $credit_type = $args['credit_type'];
        $credit_amount = intval($args['credit_amount']);

        $credit_type = sanitize_text_field($credit_type);
        $credit_amount = intval($credit_amount);

        if ($credit_type !== 'dalle' && $credit_type !== 'stable_diffusion') {
            return;
        }

        $credit_meta_key = 'ai_image_pro_' . $credit_type . '_credits';
        $credit = get_user_meta($user_id, $credit_meta_key, true);
        $credit = empty($credit) ? 0 : $credit;
        $credit += $credit_amount;

        update_user_meta($user_id, $credit_meta_key, $credit);
    }

    public function set_user_credit($args) {
        $user_id = intval($args['user_id']);
        $credit_type = $args['credit_type'];
        $credit_amount = intval($args['credit_amount']);

        $credit_type = sanitize_text_field($credit_type);
        $credit_amount = intval($credit_amount);

        if ($credit_type !== 'dalle' && $credit_type !== 'stable_diffusion') {
            return;
        }

        $credit_meta_key = 'ai_image_pro_' . $credit_type . '_credits';

        update_user_meta($user_id, $credit_meta_key, $credit_amount);
    }

    public function enqueue_scripts($hook) {
        if ( 'ai-image-pro_page_aiimagepro_users' != $hook && 'aiimagepro_users' != $hook ) {
            return;
        }

        $version = aiimagepro_get_plugin_version();
        if ($version === false) {
            $version = rand( 1, 10000000 );
        }

        wp_enqueue_script( 'bootstrap', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/js/bootstrap.bundle.min.js', array(), $version );
        wp_enqueue_style( 'bootstrap', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/bootstrap.min.css', array(), $version );

    }

}
