<?php

class AIImagePro_Settings
{
    const OPTION_PREFERRED_IMAGE_EXTENSION = 'aiimagepro_setting_preferred_image_extension';
    const OPTION_MAX_NUMBER_OF_HISTORY_ITEMS = 'aiimagepro_setting_max_number_of_history_items';
    const OPTION_PREFERRED_AI_EDITOR = 'aiimagepro_setting_preferred_ai_editor';
    const OPTION_OPENAI_API_KEY = 'aiimagepro_setting_openai_api_key';
    const OPTION_OPENAI_DEFAULT_IMAGE_SIZE = 'aiimagepro_setting_openai_default_image_size';
    const OPTION_OPENAI_DEFAULT_DALLE_MODEL = 'aiimagepro_setting_openai_default_model';
    const OPTION_OPENAI_DEFAULT_IMAGE_QUALITY = 'aiimagepro_setting_openai_default_image_quality';
    const OPTION_OPENAI_DEFAULT_IMAGE_STYLE = 'aiimagepro_setting_openai_default_image_style';
    const OPTION_STABILITY_AI_API_KEY = 'aiimagepro_setting_stability_ai_api_key';
    const OPTION_STABILITY_AI_DEFAULT_MODEL = 'aiimagepro_setting_stability_ai_default_model';
    const OPTION_STABILITY_AI_NUMBER_OF_STEPS = 'aiimagepro_setting_stability_ai_default_number_of_steps';
    const OPTION_STABILITY_AI_DEFAULT_SAMPLER = 'aiimagepro_setting_stability_ai_default_sampler';

    const OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH = 'aiimagepro_setting_stability_ai_default_image_width';
    const OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT = 'aiimagepro_setting_stability_ai_default_image_height';
    const OPTION_PLUGIN_VERSION = 'aiimagepro_plugin_version';

    const OPTION_ENABLE_IN_FRONTEND = 'aiimagepro_enable_in_frontend';

    const OPTION_ENABLE_IN_FRONTEND_FOR_ROLE = 'aiimagepro_enable_in_frontend_for_role';

    const OPTION_IS_CREDITS_ENABLED = 'aiimagepro_is_credits_enabled';

    const OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS = 'aiimagepro_redirect_for_non_logged_in_users';

    const OPTION_MESSAGE_FOR_NON_LOGGED_IN_USERS = 'aiimagepro_message_for_non_logged_in_users';

    // singleton instance
    private static $instance;

    // singleton constructor
    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function get_all_options () {
        return array (
            self::OPTION_PREFERRED_IMAGE_EXTENSION => 'png',
            self::OPTION_MAX_NUMBER_OF_HISTORY_ITEMS => 30,
            self::OPTION_PREFERRED_AI_EDITOR => 'dalle',
            self::OPTION_OPENAI_API_KEY => '',
            self::OPTION_STABILITY_AI_API_KEY => '',
            self::OPTION_STABILITY_AI_DEFAULT_MODEL => 'stable-diffusion-512-v2-1',
            self::OPTION_STABILITY_AI_NUMBER_OF_STEPS => 30,
            self::OPTION_STABILITY_AI_DEFAULT_SAMPLER => 'K_EULER_ANCESTRAL',
            self::OPTION_PLUGIN_VERSION => aiimagepro_get_plugin_version(),
            self::OPTION_ENABLE_IN_FRONTEND => '0',
            self::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE => 'any',
            self::OPTION_IS_CREDITS_ENABLED => '0',
            self::OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH => 512,
            self::OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT => 512,
            self::OPTION_OPENAI_DEFAULT_IMAGE_SIZE => 'medium',
            self::OPTION_OPENAI_DEFAULT_DALLE_MODEL => 'dall-e-2',
            self::OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS => '',
        );
    }

    public function init_options()
    {
        $options = $this->get_all_options();
        foreach ($options as $option => $defaultValue) {
            if (get_option($option) === false) {
                $this->update_option($option, $defaultValue);
            }
        }
    }

    public function init_options_if_needed()
    {
        if (aiimagepro_get_plugin_version() !== $this->get_option(self::OPTION_PLUGIN_VERSION)) {
            $this->init_options();
        }
    }

    public function delete_options()
    {
        $options = $this->get_all_options();
        foreach ($options as $option => $defaultValue) {
            delete_option($option);
        }
    }

    public function get_option($option)
    {
        return get_option($option);
    }

    public function update_option($option, $value)
    {
        return update_option($option, $value);
    }

    public function render()
    {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
            <form action="options.php" method="post">
                <?php
                // output security fields for the registered setting
                settings_fields( 'aiimagepro_options' );
                // output setting sections and their fields
                do_settings_sections( 'aiimagepro' );
                // output save settings button
                submit_button( esc_html__( 'Save Settings', 'ai-image-pro' ) );
                ?>
            </form>
        </div>
        <?php
    }

    public function register_settings()
    {
        add_settings_section(
            'aiimagepro_general_settings_section',
            esc_html__( 'General Settings', 'ai-image-pro' ),
            array ($this, 'aiimagepro_general_settings_section_callback'),
            'aiimagepro'
        );

        // Preferred image extension
        register_setting('aiimagepro_options', self::OPTION_PREFERRED_IMAGE_EXTENSION);

        add_settings_field(
            self::OPTION_PREFERRED_IMAGE_EXTENSION,
            esc_html__( 'Preferred image extension', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_preferred_image_extension_callback'),
            'aiimagepro',
            'aiimagepro_general_settings_section'
        );

        // Max number of history items
        register_setting('aiimagepro_options', self::OPTION_MAX_NUMBER_OF_HISTORY_ITEMS);

        add_settings_field(
            self::OPTION_MAX_NUMBER_OF_HISTORY_ITEMS,
            esc_html__( 'Maximum number of history items (undo/redo)', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_max_number_of_history_items_callback'),
            'aiimagepro',
            'aiimagepro_general_settings_section'
        );

        // preferred ai editor
        register_setting('aiimagepro_options', self::OPTION_PREFERRED_AI_EDITOR);

        add_settings_field(
            self::OPTION_PREFERRED_AI_EDITOR,
            esc_html__( 'Preferred AI Editor', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_preferred_ai_editor_callback'),
            'aiimagepro',
            'aiimagepro_general_settings_section'
        );

        $this->register_dalle_settings();
        $this->register_stability_ai_settings();
        $this->register_frontend_settings();
    }

    function register_dalle_settings () {
        add_settings_section(
            'aiimagepro_dalle_settings_section',
            esc_html__( 'OpenAI (Dall.E) Settings', 'ai-image-pro' ),
            array ($this, 'aiimagepro_dalle_settings_section_callback'),
            'aiimagepro'
        );

        // OpenAI API Key
        register_setting('aiimagepro_options', self::OPTION_OPENAI_API_KEY);

        add_settings_field(
            self::OPTION_OPENAI_API_KEY,
            esc_html__( 'OpenAI API key', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_openai_api_key_callback'),
            'aiimagepro',
            'aiimagepro_dalle_settings_section'
        );

        // default image size
        register_setting('aiimagepro_options', self::OPTION_OPENAI_DEFAULT_IMAGE_SIZE);

        add_settings_field(
            self::OPTION_OPENAI_DEFAULT_IMAGE_SIZE,
            esc_html__( 'Default image size', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_openai_default_image_size_callback'),
            'aiimagepro',
            'aiimagepro_dalle_settings_section'
        );

        // default image size
        register_setting('aiimagepro_options', self::OPTION_OPENAI_DEFAULT_DALLE_MODEL);

        add_settings_field(
            self::OPTION_OPENAI_DEFAULT_DALLE_MODEL,
            esc_html__( 'Default Dall.E model', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_openai_default_dalle_model_callback'),
            'aiimagepro',
            'aiimagepro_dalle_settings_section'
        );

    }

    function register_stability_ai_settings () {
        add_settings_section(
            'aiimagepro_stability_ai_settings_section',
            esc_html__( 'Stable Diffusion (Stability.ai) Settings', 'ai-image-pro' ),
            array ($this, 'aiimagepro_stability_ai_settings_section_callback'),
            'aiimagepro'
        );

        // Stability AI API Key
        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_API_KEY);

        add_settings_field(
            self::OPTION_STABILITY_AI_API_KEY,
            esc_html__( 'Stability.ai API key', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_api_key_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );

        // Default model
        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_DEFAULT_MODEL);

        add_settings_field(
            self::OPTION_STABILITY_AI_DEFAULT_MODEL,
            esc_html__( 'Default model', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_default_model_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );

        // Default number of steps
        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_NUMBER_OF_STEPS);

        add_settings_field(
            self::OPTION_STABILITY_AI_NUMBER_OF_STEPS,
            esc_html__( 'Default number of steps', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_default_number_of_steps_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );

        // Default sampler
        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_DEFAULT_SAMPLER);

        add_settings_field(
            self::OPTION_STABILITY_AI_DEFAULT_SAMPLER,
            esc_html__( 'Default sampler', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_default_sampler_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );

        // default image width

        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH);

        add_settings_field(
            self::OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH,
            esc_html__( 'Default image width', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_default_image_width_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );

        // default image height

        register_setting('aiimagepro_options', self::OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT);

        add_settings_field(
            self::OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT,
            esc_html__( 'Default image height', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_stability_ai_default_image_height_callback'),
            'aiimagepro',
            'aiimagepro_stability_ai_settings_section'
        );
    }

    function aiimagepro_setting_openai_default_dalle_model_callback()
    {
        $value = get_option(self::OPTION_OPENAI_DEFAULT_DALLE_MODEL);
        ?>
        <select name="aiimagepro_setting_openai_default_model">
            <option value="dall-e-2" <?php selected('dall-e-2', $value, true); ?>><?php echo esc_html__( 'Dall.E 2', 'ai-image-pro' ); ?></option>
            <option value="dall-e-3" <?php selected('dall-e-3', $value, true); ?>><?php echo esc_html__( 'Dall.E 3', 'ai-image-pro' ); ?></option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('The default Dall.E model that will be used when generating an image using OpenAI (Dall.E).', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php

    }

    function aiimagepro_setting_openai_default_image_size_callback () {
        $value = get_option(self::OPTION_OPENAI_DEFAULT_IMAGE_SIZE);
        ?>
        <select name="aiimagepro_setting_openai_default_image_size">
            <option value="small" <?php selected('small', $value, true); ?>><?php echo esc_html__( 'Small (256x256px)', 'ai-image-pro' ); ?></option>
            <option value="medium" <?php selected('medium', $value, true); ?>><?php echo esc_html__( 'Medium (512x512px)', 'ai-image-pro' ); ?></option>
            <option value="large" <?php selected('large', $value, true); ?>><?php echo esc_html__( 'Large (1024x1024px)', 'ai-image-pro' ); ?></option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('The default image size that will be used when generating an image using OpenAI (Dall.e).', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_default_image_width_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH);
        ?>
        <input type="range" step="64" min="128" max="1024" name="aiimagepro_setting_stability_ai_default_image_width" value="<?php echo $value; ?>" oninput="this.nextElementSibling.value = this.value" />
        <output><?php echo $value; ?></output> px
        <p>
            <small>
                <?php
                echo esc_html__('The default image width that will be used when generating an image using Stability.ai.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_default_image_height_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT);
        ?>
        <input type="range" step="64" min="128" max="1024" name="aiimagepro_setting_stability_ai_default_image_height" value="<?php echo $value; ?>" oninput="this.nextElementSibling.value = this.value" />
        <output><?php echo $value; ?></output> px
        <p>
            <small>
                <?php
                echo esc_html__('The default image height that will be used when generating an image using Stability.ai.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_general_settings_section_callback() {
        ?>
        <div class="ai-image-pro-settings-section">
            <div class="ai-image-pro-settings-section-button">
                <a href="https://youtu.be/qZgAJ-2ky9s" target="_blank" class="button button-primary">
                    &#9658;
                    <?php
                    echo esc_html__('Watch video tutorial', 'ai-image-pro');
                    ?>
                </a>
            </div>
            <div class="ai-image-pro-settings-section-content">
                <p>
                    <?php
                    echo esc_html__('For more information on how to configure and use AI Image Pro, please watch the video tutorial by clicking on the link on the right.', 'ai-image-pro');
                    ?>
                </p>
            </div>
        </div>
        <?php
    }

    function aiimagepro_setting_preferred_image_extension_callback() {
        $value = get_option(self::OPTION_PREFERRED_IMAGE_EXTENSION);
        ?>
        <select name="aiimagepro_setting_preferred_image_extension">
            <option selected value="png" <?php selected('png', $value, true); ?>>PNG</option>
            <option value="jpg" <?php selected('jpg', $value, true); ?>>JPG</option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('Choose your preferred image extension in which images will be saved. PNG allows for transparency, but consumes a bit more space, while JPG doesn\'t allow for transparency but more space-efficient.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_max_number_of_history_items_callback() {
        $value = get_option(self::OPTION_MAX_NUMBER_OF_HISTORY_ITEMS);
        ?>
        <input type="number" min="0" step="1" name="aiimagepro_setting_max_number_of_history_items" value="<?php echo $value; ?>" />
        <p>
            <small>
                <?php
                echo esc_html__('The maximum number of history items (undo/redo) that will be saved in the editor. Depending on your computer resources you might want to increase/decrease this amount as more steps will consume more resources in your web browser. Setting it to 0 will disable history.', 'ai-image-pro');
                ?>
            </small>
        <?php
    }

    function aiimagepro_setting_preferred_ai_editor_callback() {
        $value = get_option(self::OPTION_PREFERRED_AI_EDITOR);
        ?>
        <select name="aiimagepro_setting_preferred_ai_editor">
            <option selected value="dalle" <?php selected('ai', $value, true); ?>><?php echo esc_html__( 'Dall.E', 'ai-image-pro' ); ?></option>
            <option value="stability-ai" <?php selected('stability-ai', $value, true); ?>><?php echo esc_html__( 'Stable Diffusion (Stability AI)', 'ai-image-pro' ); ?></option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('Choose your preferred AI editor. Your preferred AI editor will appear first in the editor.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_dalle_settings_section_callback () {

    }

    function aiimagepro_stability_ai_settings_section_callback () {

    }

    function aiimagepro_setting_openai_api_key_callback () {
        $value = get_option(self::OPTION_OPENAI_API_KEY);
        ?>
        <input size="80" type="text" name="aiimagepro_setting_openai_api_key" value="<?php echo $value; ?>" />
        <p>
            <small>
                <?php
                echo esc_html__('Your OpenAI API key. You can get your API key by signing up for an account at ', 'ai-image-pro') . '<a href="https://platform.openai.com/signup">https://platform.openai.com/signup</a>';
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_api_key_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_API_KEY);
        ?>
        <input size="80" type="text" name="aiimagepro_setting_stability_ai_api_key" value="<?php echo $value; ?>" />
        <p>
            <small>
                <?php
                echo esc_html__('Your Stability.ai API key. You can get your API key by signing up for an account at ', 'ai-image-pro') . '<a href="https://beta.dreamstudio.ai/">https://beta.dreamstudio.ai/</a>';
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_default_model_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_DEFAULT_MODEL);
        ?>
        <select name="aiimagepro_setting_stability_ai_default_model">
            <option value="stable-diffusion-v1-6" <?php selected('stable-diffusion-v1-6', $value, true); ?>><?php echo esc_html__( 'Stable Diffusion v1.6', 'ai-image-pro' ); ?></option>
            <option value="stable-diffusion-xl-beta-v2-2-2" <?php selected('stable-diffusion-xl-beta-v2-2-2', $value, true); ?>><?php echo esc_html__( 'Stable Diffusion v2.2.2-XL Beta', 'ai-image-pro' ); ?></option>
            <option value="stable-diffusion-xl-1024-v0-9" <?php selected('stable-diffusion-xl-1024-v0-9', $value, true); ?>><?php echo esc_html__( 'Stable Diffusion XL v0.9', 'ai-image-pro' ); ?></option>
            <option value="stable-diffusion-xl-1024-v1-0" <?php selected('stable-diffusion-xl-1024-v1-0', $value, true); ?>><?php echo esc_html__( 'Stable Diffusion XL v1.0', 'ai-image-pro' ); ?></option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('The default model that will be used when generating an image using Stability.ai.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_default_number_of_steps_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_NUMBER_OF_STEPS);
        ?>
        <input type="number" step="1" min="10" max="150" name="aiimagepro_setting_stability_ai_default_number_of_steps" value="<?php echo $value; ?>" />
        <p>
            <small>
                <?php
                echo esc_html__('The default number of steps that will be used when generating an image using Stability.ai.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    function aiimagepro_setting_stability_ai_default_sampler_callback () {
        $value = get_option(self::OPTION_STABILITY_AI_DEFAULT_SAMPLER);
        ?>
        <select name="aiimagepro_setting_stability_ai_default_sampler">
            <option value="DDIM" <?php selected('DDIM', $value, true); ?>><?php echo esc_html__( 'DDIM', 'ai-image-pro' ); ?></option>
            <option value="DDPM" <?php selected('DDPM', $value, true); ?>><?php echo esc_html__( 'DDPM', 'ai-image-pro' ); ?></option>
            <option value="K_DPMPP_2M" <?php selected('K_DPMPP_2M', $value, true); ?>><?php echo esc_html__( 'K_DPMPP_2M', 'ai-image-pro' ); ?></option>
            <option value="K_DPMPP_2S_ANCESTRAL" <?php selected('K_DPMPP_2S_ANCESTRAL', $value, true); ?>><?php echo esc_html__( 'K_DPMPP_2S_ANCESTRAL', 'ai-image-pro' ); ?></option>
            <option value="K_DPM_2" <?php selected('K_DPM_2', $value, true); ?>><?php echo esc_html__( 'K_DPM_2', 'ai-image-pro' ); ?></option>
            <option value="K_DPM_2_ANCESTRAL" <?php selected('K_DPM_2_ANCESTRAL', $value, true); ?>><?php echo esc_html__( 'K_DPM_2_ANCESTRAL', 'ai-image-pro' ); ?></option>
            <option value="K_EULER" <?php selected('K_EULER', $value, true); ?>><?php echo esc_html__( 'K_EULER', 'ai-image-pro' ); ?></option>
            <option value="K_EULER_ANCESTRAL" <?php selected('K_EULER_ANCESTRAL', $value, true); ?>><?php echo esc_html__( 'K_EULER_ANCESTRAL', 'ai-image-pro' ); ?></option>
            <option value="K_HEUN" <?php selected('K_HEUN', $value, true); ?>><?php echo esc_html__( 'K_HEUN', 'ai-image-pro' ); ?></option>
            <option value="K_LMS" <?php selected('K_LMS', $value, true); ?>><?php echo esc_html__( 'K_LMS', 'ai-image-pro' ); ?></option>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('Choose your preferred sampler that will be used when generating images with Stability.ai', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    public function admin_config_notice() {
        $this->max_upload_notice();
        $this->configure_plugin_notice();
    }

    private function max_upload_notice()
    {
        if (!isset($_GET['page']) || $_GET['page'] !== 'aiimagepro_image_editor_settings') {
            return;
        }

        $maxUploadSize = wp_max_upload_size();
        $maxUploadSize = $maxUploadSize / 1024 / 1024;
        $maxUploadSize = round($maxUploadSize, 2);

        if ($maxUploadSize < 20) {
            ?>
            <div id="ai-image-pro-notice" class="notice-warning notice is-dismissible">

                <div class="ai-image-pro-notice-txt">
                    <p>
                        <?php echo esc_html__('For the best experience, AI Image Pro requires a minimum upload size of 20MB. Please increase your upload size to avoid getting error when editing bigger images. Ask you hosting provider, or', 'ai-image-pro')?> <a href="https://www.wpbeginner.com/wp-tutorials/how-to-increase-the-maximum-file-upload-size-in-wordpress/" target="_blank"><?php echo esc_html__(' follow this guide ', 'ai-image-pro')?></a> <?php echo esc_html__('for more information.', 'ai-image-pro')?>
                    </p>
                </div>
            </div>
            <?php
        }
    }

    private function configure_plugin_notice()
    {
        global $pagenow;

        if ($pagenow !== 'plugins.php') {
            return;
        }

        // if neither openai not stability ai keys are set, show the notice
        $openaiKey = $this->get_option(self::OPTION_OPENAI_API_KEY);
        $stabilityAiKey = $this->get_option(self::OPTION_STABILITY_AI_API_KEY);

        if ( empty($openaiKey) && empty($stabilityAiKey) ) {
            ?>
            <div id="ai-image-pro-notice" class="updated notice is-dismissible">

                <div class="ai-image-pro-notice-txt">
                    <p>
                        <?php echo esc_html__('Thank you for purchasing AI Image Pro! Please consider entering your AI API keys in order to start leveraging AI image generation.', 'ai-image-pro')?>
                    </p>
                </div>
                <div class="ai-image-pro-btn-container">
                    <a href="<?php echo admin_url( 'admin.php?page=aiimagepro_image_editor_settings' ); ?>" id="ai-image-pro-btn"><?php echo esc_html__('Configure AI Image Pro', 'ai-image-pro')?></a>
                </div>
            </div>
            <?php
        }
    }

    private function register_frontend_settings()
    {
        add_settings_section(
            'aiimagepro_frontend_settings_section',
            esc_html__( 'Frontend Integration Settings', 'ai-image-pro' ),
            array ($this, 'aiimagepro_frontend_settings_section_callback'),
            'aiimagepro'
        );

        // Enable in frontend
        register_setting('aiimagepro_options', self::OPTION_ENABLE_IN_FRONTEND);

        add_settings_field(
            self::OPTION_ENABLE_IN_FRONTEND,
            esc_html__( 'Enable in Frontend', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_enable_in_frontend_callback'),
            'aiimagepro',
            'aiimagepro_frontend_settings_section'
        );

        // Enable in frontend for role
        register_setting('aiimagepro_options', self::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE);

        add_settings_field(
            self::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE,
            esc_html__( 'Enable in Frontend For Role', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_enable_in_frontend_for_role_callback'),
            'aiimagepro',
            'aiimagepro_frontend_settings_section'
        );

        // is credits enabled
        register_setting('aiimagepro_options', self::OPTION_IS_CREDITS_ENABLED);

        add_settings_field(
            self::OPTION_IS_CREDITS_ENABLED,
            esc_html__( 'Enable Credits', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_is_credits_enabled_callback'),
            'aiimagepro',
            'aiimagepro_frontend_settings_section'
        );

        // Redirect for non-logged in users
        register_setting('aiimagepro_options', self::OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS);

        add_settings_field(
            self::OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS,
            esc_html__( 'Redirect for non-logged in (or unauthorized) users', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_redirect_for_non_logged_in_users_callback'),
            'aiimagepro',
            'aiimagepro_frontend_settings_section'
        );

        // Message for non-logged in users
        register_setting('aiimagepro_options', self::OPTION_MESSAGE_FOR_NON_LOGGED_IN_USERS);

        add_settings_field(
            self::OPTION_MESSAGE_FOR_NON_LOGGED_IN_USERS,
            esc_html__( 'Message for non-logged in (or unauthorized) users', 'ai-image-pro' ),
            array ($this, 'aiimagepro_setting_message_for_non_logged_in_users_callback'),
            'aiimagepro',
            'aiimagepro_frontend_settings_section'
        );

    }

    public function aiimagepro_setting_message_for_non_logged_in_users_callback()
    {
        $value = get_option(self::OPTION_MESSAGE_FOR_NON_LOGGED_IN_USERS);
        ?>
        <textarea rows="5" cols="80" name="aiimagepro_message_for_non_logged_in_users"><?php echo $value; ?></textarea>
        <p>
            <small>
                <?php
                echo esc_html__('If you want to show a message to non-logged in (or unauthorized) users, enter the message here (html is supported).', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    public function aiimagepro_setting_redirect_for_non_logged_in_users_callback()
    {
        $value = get_option(self::OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS);
        ?>
        <input size="80" type="text" name="aiimagepro_redirect_for_non_logged_in_users" value="<?php echo $value; ?>" />
        <p>
            <small>
                <?php
                echo esc_html__('If you want to redirect non-logged in (or unauthorized) users to a specific page, enter the URL of that page here. (enter a relative url like "/wp-login.php")', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php

    }

    public function aiimagepro_setting_is_credits_enabled_callback() {
        $setting = get_option(self::OPTION_IS_CREDITS_ENABLED);

        ?>
        <input type="checkbox" name="<?php echo self::OPTION_IS_CREDITS_ENABLED; ?>" value="1" <?php checked(1, $setting, true); ?> />
        <p>
            <small>
                <?php
                echo sprintf(esc_html__('Enable Credits in frontend. If enabled, users will only be able to generate images if they have credit. User credit will be read from the following user meta keys: %s and %s. Make sure to set the values of these user meta data keys when you sign up your users to use your service.', 'ai-image-pro'), '<code>ai_image_pro_dalle_credits</code>', '<code>ai_image_pro_stable_diffusion_credits</code>');
                ?>
            </small>
        </p>
        <?php
    }

    public function aiimagepro_frontend_settings_section_callback() {
        ?>
            <p>
                <small>
                    <?php
                    echo esc_html__('Configure how AI Image Pro will be integrated in frontend.', 'ai-image-pro');
                    echo esc_html__(' You can use the short code', 'ai-image-pro') . ' <code>[ai_image_pro]</code> ' . esc_html__('to display the AI Image Pro editor in frontend.', 'ai-image-pro');
                    echo esc_html__(' You can pass the following short code options to customize the editor:', 'ai-image-pro');
                    echo '<ul style="list-style-type: disc; margin-left: 20px;">';
                    echo '<li><code>show_logo</code>: ' . esc_html__('Set to "1" to show the AI Image Pro logo in frontend, "0" to hide it.', 'ai-image-pro') . '</li>';
                    echo '<li><code>show_credits</code>: ' . esc_html__('Set to 1 to show the user credits in frontend, "0" to hide it.', 'ai-image-pro') . '</li>';
                    echo '<li><code>height</code>: ' . esc_html__('Set the height of the editor in frontend.', 'ai-image-pro') . '</li>';
                    echo '<li><code>width</code>: ' . esc_html__('Set the height of the editor in frontend.', 'ai-image-pro') . '</li>';
                    echo '<li><code>scrolling</code>: ' . esc_html__('Set to "yes" to enable scrolling in frontend, "no" to disable it.', 'ai-image-pro') . '</li>';
                    echo '</ul>';

                    ?>
                </small>
            </p>
        <?php
    }

    public function aiimagepro_setting_enable_in_frontend_callback() {
        $setting = get_option(self::OPTION_ENABLE_IN_FRONTEND);

        ?>
        <input type="checkbox" name="<?php echo self::OPTION_ENABLE_IN_FRONTEND; ?>" value="1" <?php checked(1, $setting, true); ?> />
        <p>
            <small>
                <?php
                echo esc_html__('Enable AI Image Pro in frontend. If disabled, AI Image Pro will not be loaded in frontend.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php
    }

    public function aiimagepro_setting_enable_in_frontend_for_role_callback() {
        $setting = get_option(self::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE);

        ?>
        <select name="<?php echo self::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE; ?>">
            <option value="any"><?php echo esc_html__( 'Any', 'ai-image-pro' ); ?></option>
            <?php
            $roles = get_editable_roles();
            foreach ($roles as $role => $details) {
                ?>
                <option value="<?php echo $role; ?>" <?php selected($role, $setting, true); ?>><?php echo $details['name']; ?></option>
                <?php
            }
            ?>
        </select>
        <p>
            <small>
                <?php
                echo esc_html__('Enable AI Image Pro in frontend for a specific role. If enabled, AI Image Pro will only be loaded in frontend for the selected role.', 'ai-image-pro');
                ?>
            </small>
        </p>
        <?php

    }
}
