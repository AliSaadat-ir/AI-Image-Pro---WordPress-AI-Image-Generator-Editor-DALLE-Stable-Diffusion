<?php

class AIImagePro_Editor
{
    private AIImagePro_Settings $settings;
    public function __construct()
    {
        $this->settings = AIImagePro_Settings::instance();
        add_shortcode('ai_image_pro', array($this, 'editor_shortcode'));
        add_action('pre_get_posts', array($this,'filter_media_library'));
    }
    public function render()
    {
        $preferred_editor = $this->settings->get_option(AIImagePro_Settings::OPTION_PREFERRED_AI_EDITOR);

        $first_tab_id = $preferred_editor === 'dalle' ? 'dalle' : 'stability-ai';
        $second_tab_id = $preferred_editor === 'dalle' ? 'stability-ai' : 'dalle';

        $first_title = $preferred_editor === 'dalle' ? esc_html__('Dall.E', 'ai-image-pro') : esc_html__('Stable Diffusion', 'ai-image-pro');
        $second_title = $preferred_editor === 'dalle' ? esc_html__('Stable Diffusion', 'ai-image-pro') : esc_html__('Dall.E', 'ai-image-pro');

        $url_to_icon = plugins_url('../../assets/icons/ai-image-pro-icon.svg', __FILE__ );

        ###['demo-message']

        $show_logo = true;
        if (isset($_GET['showLogo'])) {
            $show_logo = $_GET['showLogo'] == '1';
        }

        $show_credit_score = false;
        if (isset($_GET['showCredits'])) {
            $show_credit_score = $_GET['showCredits'] == '1';
        }

        ?>
        <div class="wrap ai-image-pro-editor-container" >
            <?php
            if ($show_logo) {
                ?>
            <div class="ai-image-pro-heading-container">
                <img class="ai-image-pro-logo" src="<?php echo $url_to_icon; ?>" />
                <h1 class="ai-image-pro-heading"><?php echo esc_html( get_admin_page_title() ); ?></h1>
            </div>
            <?php }

                if ($show_credit_score) {
                    $user_id = get_current_user_id();
                    $dalle_credits = get_user_meta($user_id, 'ai_image_pro_dalle_credits', true);
                    $dalle_credits = empty($dalle_credits) ? 0 : $dalle_credits;
                    $stable_diffusion_credits = get_user_meta($user_id, 'ai_image_pro_stable_diffusion_credits', true);
                    $stable_diffusion_credits = empty($stable_diffusion_credits) ? 0 : $stable_diffusion_credits;
            ?>
            <div class="row justify-content-end align-content-end text-end mb-4">
                <div class="col-auto ai-image-pro-credit-score-container me-0">
                    <div class="row">
                        <div class="col-auto">
                            <div class="ai-image-pro-score-name text-center"><?php echo esc_html__('Dall.E', 'ai-image-pro') ?></div>
                            <div class="ai-image-pro-score-value text-center" id="ai-image-pro-dalle-credits"><?php echo $dalle_credits ?></div>
                        </div>
                        <div class="col-auto">
                            <div class="ai-image-pro-score-name text-center"><?php echo esc_html__('Stable Diffusion', 'ai-image-pro') ?></div>
                            <div class="ai-image-pro-score-value text-center stable_diffusion_credit" id="ai-image-pro-stable-diffusion-credits"><?php echo $stable_diffusion_credits ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            <div class="row mt-2">
                <div class="col-4">
                    <div class="row">
                        <div class="col-12">
                            <div id="ai-image-pro-editor" class="">
                                <ul class="nav nav-tabs border border-0" id="ai-image-pro-editor-tabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="<?php echo $first_tab_id ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo $first_tab_id ?>-pane" type="button" role="tab" aria-controls="home-tab-pane" ><?php echo $first_title ?></button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="<?php echo $second_tab_id ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo $second_tab_id ?>-pane" type="button" role="tab" aria-controls="profile-tab-pane" ><?php echo $second_title ?></button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="ai-image-pro-editor-panes">
                                    <div class="tab-pane fade show active" id="<?php echo $first_tab_id ?>-pane" role="tabpanel" aria-labelledby="<?php echo $first_tab_id ?>-tab" tabindex="0">
                                        <?php $this->get_tab_content($first_tab_id); ?>
                                    </div>
                                    <div class="tab-pane fade" id="<?php echo $second_tab_id ?>-pane" role="tabpanel" aria-labelledby="dream-studio-tab" tabindex="0">
                                        <?php $this->get_tab_content($second_tab_id); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <div id="ai-image-pro-multiple-images-generations-pane-container">
                                <h6><?php echo esc_html__( 'Image generations', 'ai-image-pro' ); ?></h6>
                                <div id="ai-image-pro-multiple-images-generations-pane">
                                    <div id="ai-image-pro-multiple-images-generations">
                                        <div class="row">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-8 ai-image-pro-image-controls-container">
                    <div class="row">
                        <div class="col-12 ai-image-pro-undo-redo-toolbar d-flex justify-content-center">
                            <button id="ai-image-pro-undo-button" type="button" class="btn btn-outline-secondary btn-sm m-1 float-start disabled"><i class="bi bi-arrow-counterclockwise"></i></button>
                            <button id="ai-image-pro-redo-button" type="button" class="btn btn-outline-secondary btn-sm m-1 float-start disabled"><i class="bi bi-arrow-clockwise"></i></button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <button id="ai-image-pro-media-library-button" type="button" class="btn btn-outline-secondary btn-sm m-1 float-start"><i class="bi bi-image"></i> <?php echo esc_html__( 'Import', 'ai-image-pro' ); ?></button>
                        </div>
                        <div class="col-6">
                            <?php $this->toolbar(); ?>
                        </div>
                        <div class="col-3 justify-content-end">
                            <button id="ai-image-pro-save-to-media-gallery-button" type="button" class="btn btn-sm btn-outline-success m-1 float-end disabled"><i class="bi bi-check-circle-fill"></i> <?php echo esc_html__( 'Save', 'ai-image-pro' ); ?></button>
                            <button id="ai-image-pro-download-image-button" type="button" class="btn btn-sm btn-outline-primary m-1 float-end disabled"><i class="bi bi-download"></i> <?php echo esc_html__( 'Download', 'ai-image-pro' ); ?></button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col text-center">
                            <?php $this->toolbarPanes(); ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="ai-image-pro-editor-canvas-container-container" >
                                <div class="ai-image-pro-editor-canvas-container">
                                    <div class="ai-image-pro-editor-main-canvas-container">
                                        <canvas id="ai-image-pro-editor-canvas" ></canvas>
                                    </div>
                                    <div class="ai-image-pro-editor-mask-canvas-container">
                                        <canvas id="ai-image-pro-mask-canvas" ></canvas>
                                    </div>
                                    <div class="ai-image-pro-editor-cropper-container">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div id="ai-image-pro-editor-toolbar-item-brush-size-slider">
                <div class="row d-flex justify-content-center mt-1">
                    <div class="col">
                        <input type="range" class="form-range" min="1" max="100" value="20" step="1" id="ai-image-pro-editor-toolbar-item-brush-size-slider-range">
                    </div>
                </div>
                <div class="row d-flex justify-content-center mt-1">
                    <div class="col">
                        <button id="ai-image-pro-editor-toolbar-item-clear-mask-brush" type="button" class="btn btn-outline-secondary btn-sm">
                            <span class="d-inline-block ai-image-pro-popover ai-image-pro-editor-edit-image-tip" data-bs-toggle="popover" data-bs-trigger="manual" data-bs-content="<?php echo esc_html__( 'Brush over the parts in the images that you want AI to edit.', 'ai-image-pro' ); ?>">
                                <i class="bi bi-trash3"></i>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div id="ai-image-pro-editor-overlay"></div>

            <div id="ai-image-pro-multiple-images-selector">
                <h3><?php echo esc_html__( 'Pick an image', 'ai-image-pro' ); ?></h3>
                <p><?php echo esc_html__( 'Don\'t worry, the rest of the images will not go anywhere. You can always pick any of these images from the side image pane later.', 'ai-image-pro' ); ?></p>
                <div id="ai-image-pro-multiple-images-selector-container">
                </div>

                <div id="ai-image-pro-multiple-images-selector-button-controls" class="float-end mt-4">
                    <a href="#" id="ai-image-pro-multiple-images-cancel-button"><?php echo esc_html__( 'Cancel', 'ai-image-pro' ); ?></a>
                    <button id="ai-image-pro-multiple-images-pick-button" type="button" class="btn btn-outline-secondary disabled"><?php echo esc_html__( 'Pick this image', 'ai-image-pro' ); ?></button>
                </div>

                <div id="ai-image-pro-multiple-images-selector-close">
                    <button type="button" class="btn-close btn-close-white ai-image-pro-multiple-images-selector-close-button" aria-label="Close"></button>
                </div>
            </div>

            <div class="ai-image-pro-dev-tools">
                <h6>Dev tools</h6>
                <div>
                    <button id="ai-image-pro-download-mask-button" type="button" class="btn btn-sm btn-outline-secondary"><?php echo esc_html__( 'Download Mask', 'ai-image-pro' ); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function get_tab_content($editor_id)
    {
        if ($editor_id == 'dalle') {
            $this->dalle();
        } else {
            $this->stability_ai();
        }
    }

    private function dalle()
    {
        ?>
        <ul class="nav nav-pills nav-fill nav-justified" role="tablist">
            <li class="nav-item border-radius-left" role="presentation">
                <a class="nav-link active" aria-current="page" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-dalle-generate-pane"> <i class="bi bi-images"></i> <?php echo esc_html__( 'Generate', 'ai-image-pro' ); ?></a>
            </li>
            <li class="nav-item no-border-radius" role="presentation">
                <a class="nav-link" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-dalle-edit-pane"><i class="bi bi-pencil" ></i> <?php echo esc_html__( 'Edit', 'ai-image-pro' ); ?></a>
            </li>
            <li class="nav-item border-radius-right" role="presentation">
                <a class="nav-link" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-dalle-variations-pane"><i class="bi bi-front"></i> <?php echo esc_html__( 'Variations', 'ai-image-pro' ); ?></a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="ai-image-pro-dalle-generate-pane" role="tabpanel" tabindex="0">
                <?php $this->dalle_pane_generate(); ?>
            </div>
            <div class="tab-pane fade" id="ai-image-pro-dalle-edit-pane" role="tabpanel" tabindex="0">
                <?php $this->dalle_pane_edit(); ?>
            </div>
            <div class="tab-pane fade" id="ai-image-pro-dalle-variations-pane" role="tabpanel" tabindex="0">
                <?php $this->dalle_pane_variations(); ?>
            </div>
        </div>


        <?php
    }

    private function dalle_pane_generate()
    {
        ?>
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <?php $this->prompt_guide(); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="form-floating">
                            <?php $this->dalle_prompt('ai-image-pro-dalle-generate-prompt'); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col">
                        <button id="ai-image-pro-dalle-generate-button" type="button" class="btn btn-sm btn-primary float-end mt-1"><i class="bi bi-images"></i> <?php echo esc_html__( 'Generate', 'ai-image-pro' ); ?></button>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->dalle_models('ai-image-pro-dalle-generate-models') ?>
                    </div>
                    <div class="col">
                        <?php $this->dalle_image_quality('ai-image-pro-dalle-generate-image-quality') ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->dalle_image_styles('ai-image-pro-dalle-generate-image-styles') ?>
                    </div>
                    <div class="col">
                        <?php $this->dalle_image_size('ai-image-pro-dalle-generate-image-size') ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->dalle_number_of_images('ai-image-pro-dalle-generate-count') ?>
                    </div>
                </div>
            </div>

        </div>
        <?php
    }

    private function dalle_pane_edit()
    {
        ?>
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <?php $this->prompt_guide(); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="form-floating">
                            <?php $this->dalle_prompt('ai-image-pro-dalle-edit-prompt'); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col float-end">
                        <button id="ai-image-pro-dalle-perform-edit-button" type="button" class="btn btn-sm float-end btn-outline-secondary m-1"><i class="bi bi-check"></i> <?php echo esc_html__( 'Confirm Edit', 'ai-image-pro' ); ?></button>
                        <button id="ai-image-pro-dalle-cancel-edit-button" type="button" class="btn btn-sm float-end btn-outline-secondary m-1"><i class="bi bi-x"></i> <?php echo esc_html__( 'Cancel', 'ai-image-pro' ); ?></button>
                        <button id="ai-image-pro-dalle-draw-mask-button" type="button" class="btn float-end btn-sm btn-primary disabled m-1 ai-image-pro-primary-button">
                            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Edit image by highlighting the parts you want the AI to edit', 'ai-image-pro' ); ?>">
                                <i class="bi bi-pencil"></i> <?php echo esc_html__( 'Start Editing', 'ai-image-pro' ); ?>
                            </span>
                        </button>
                    </div>

                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->dalle_image_size('ai-image-pro-dalle-edit-image-size') ?>
                    </div>
                    <div class="col">
                        <?php $this->dalle_number_of_images('ai-image-pro-dalle-edit-count') ?>
                    </div>
                </div>
            </div>

        </div>
        <?php
    }

    private function dalle_pane_variations()
    {
        ?>
        <div class="row">
            <div class="col-12">

                <div class="row mt-1">
                    <div class="col">
                        <?php $this->dalle_image_size('ai-image-pro-dalle-variations-image-size') ?>
                    </div>
                    <div class="col">
                        <?php $this->dalle_number_of_images('ai-image-pro-dalle-variations-count') ?>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">

                        <button id="ai-image-pro-dalle-image-variations-button" type="button" class="btn btn-sm float-end btn-primary disabled mt-1 ai-image-pro-primary-button">
                            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Generate variations that are similar to the current image.', 'ai-image-pro' ); ?>">
                                <i class="bi bi-front"></i> <?php echo esc_html__( 'Generate Variations', 'ai-image-pro' ); ?>
                            </span>
                        </button>
                    </div>

                </div>

            </div>

        </div>
        <?php
    }

    private function dalle_prompt($id)
    {
        ?>
        <textarea class="form-control ai-image-pro-prompt-input" id="<?php echo $id ?>" rows="5" cols="100" placeholder="<?php echo esc_html__( 'Prompt', 'ai-image-pro' ); ?>"></textarea>
        <label for="<?php echo $id ?>"><?php echo esc_html__( 'Prompt', 'ai-image-pro' ); ?></label>
        <?php
    }

    private function dalle_image_size($id)
    {
        $default_size = $this->settings->get_option(AIImagePro_Settings::OPTION_OPENAI_DEFAULT_IMAGE_SIZE);
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Size of generated image', 'ai-image-pro' ); ?>">
                <?php echo esc_html__( 'Image size', 'ai-image-pro' ); ?>
            </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="small" class="dall-e-2" <?php selected('small', $default_size, true); ?>><?php echo esc_html__( 'Small (256x256)', 'ai-image-pro' ); ?></option>
                <option value="medium" class="dall-e-2" <?php selected('medium', $default_size, true); ?>><?php echo esc_html__( 'Medium (512x512)', 'ai-image-pro' ); ?></option>
                <option value="large"  class="dall-e-2 dall-e-3" <?php selected('large', $default_size, true); ?>><?php echo esc_html__( 'Large (1024x1024)', 'ai-image-pro' ); ?></option>

            <?php if ($id == 'ai-image-pro-dalle-generate-image-size') { ?>
                <option value="xlarge-1792x1024" class="dall-e-3" <?php selected('xlarge-1792x1024', $default_size, true); ?>><?php echo esc_html__( 'X Large Landscape (1792x1024)', 'ai-image-pro' ); ?></option>
                <option value="xlarge-1024x1792" class="dall-e-3" <?php selected('xlarge-1024x1792', $default_size, true); ?>><?php echo esc_html__( 'X Large Portrait (1024x1792)', 'ai-image-pro' ); ?></option>
            <?php } ?>

            </select>
        </div>
        <?php
    }

    private function dalle_models($id)
    {
        $default_model = $this->settings->get_option(AIImagePro_Settings::OPTION_OPENAI_DEFAULT_DALLE_MODEL);
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Model to use for generating images', 'ai-image-pro' ); ?>">
                <?php echo esc_html__( 'Model', 'ai-image-pro' ); ?>
            </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="dall-e-2" <?php selected('dall-e-2', $default_model, true); ?>><?php echo esc_html__( 'Dall.E 2', 'ai-image-pro' ); ?></option>
                <option value="dall-e-3" <?php selected('dall-e-3', $default_model, true); ?>><?php echo esc_html__( 'Dall.E 3', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function dalle_image_quality($id)
    {
        $default_quality = $this->settings->get_option(AIImagePro_Settings::OPTION_OPENAI_DEFAULT_IMAGE_QUALITY);

        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Quality of generated image (only works with Dall.E 3)', 'ai-image-pro' ); ?>">
                <?php echo esc_html__( 'Image quality', 'ai-image-pro' ); ?>
            </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="sd" <?php selected('sd', $default_quality, true); ?>><?php echo esc_html__( 'Standard Definition', 'ai-image-pro' ); ?></option>
                <option value="hd" <?php selected('hd', $default_quality, true); ?>><?php echo esc_html__( 'High Definition', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function dalle_image_styles($id)
    {
        // vivid & natural
        $default_style = $this->settings->get_option(AIImagePro_Settings::OPTION_OPENAI_DEFAULT_IMAGE_STYLE);
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Style of generated image (only works with Dall.E 3)', 'ai-image-pro' ); ?>">
                <?php echo esc_html__( 'Image style', 'ai-image-pro' ); ?>
            </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="natural" <?php selected('natural', $default_style, true); ?>><?php echo esc_html__( 'Natural', 'ai-image-pro' ); ?></option>
                <option value="vivid" <?php selected('vivid', $default_style, true); ?>><?php echo esc_html__( 'Vivid', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function dalle_number_of_images($id)
    {
        ?>
        <div class="row mt-1">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Number of images to generate', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Number of Images', 'ai-image-pro' ); ?>
                </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" value="1" step="1" min="1" max="10">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border">1</span>
            </div>
        </div>
        <?php
    }

    private function stability_ai()
    {
        ?>
        <ul class="nav nav-pills nav-fill nav-justified">
            <li class="nav-item border-radius-left">
                <a class="nav-link active" aria-current="page" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-stabilityai-generate-pane"> <i class="bi bi-images"></i> <?php echo esc_html__( 'Generate', 'ai-image-pro' ); ?></a>
            </li>
            <li class="nav-item border-radius-right">
                <a class="nav-link" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-stabilityai-edit-pane"><i class="bi bi-pencil"></i> <?php echo esc_html__( 'Edit', 'ai-image-pro' ); ?></a>
            </li>
            <li class="nav-item border-radius-right">
                <a class="nav-link" href="#" data-bs-toggle="tab" data-bs-target="#ai-image-pro-stabilityai-upscale-pane"><i class="bi bi-zoom-in"></i> <?php echo esc_html__( 'Upscale', 'ai-image-pro' ); ?></a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="ai-image-pro-stabilityai-generate-pane" role="tabpanel" tabindex="0">
                <?php $this->stability_ai_pane_generate(); ?>
            </div>
            <div class="tab-pane fade" id="ai-image-pro-stabilityai-edit-pane" role="tabpanel" tabindex="0">
                <?php $this->stability_ai_pane_edit(); ?>
            </div>
            <div class="tab-pane fade" id="ai-image-pro-stabilityai-upscale-pane" role="tabpanel" tabindex="0">
                <?php $this->stability_ai_pane_upscale(); ?>
            </div>
        </div>


        <?php
    }

    private function stability_ai_pane_generate()
    {
        ?>
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <?php $this->prompt_guide(); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <?php $this->stability_ai_prompt('ai-image-pro-stabilityai-generate-prompt'); ?>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col">
                        <button id="ai-image-pro-stabilityai-generate-button" type="button" class="btn btn-sm btn-primary float-end mt-1"><i class="bi bi-images"></i> <?php echo esc_html__( 'Generate', 'ai-image-pro' ); ?></button>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->stability_ai_model('ai-image-pro-stabilityai-generate-engine'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_styles('ai-image-pro-stabilityai-generate-styles'); ?>
                    </div>
                </div>
                <div class="row mt-3 p-2">

                    <div class="col">
                        <?php $this->stability_ai_width('ai-image-pro-stabilityai-generate-image-width'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_height('ai-image-pro-stabilityai-generate-image-height'); ?>
                    </div>

                </div>

                <div class="row mt-3 p-2">

                    <div class="col">
                        <?php $this->stability_ai_number_of_images('ai-image-pro-stabilityai-generate-count'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_number_of_steps('ai-image-pro-stabilityai-generate-steps'); ?>
                    </div>
                </div>

                <div class="row mt-3 p-2">
                    <div class="col">
                        <?php $this->stability_ai_cfg_scale('ai-image-pro-stabilityai-generate-cfg'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_sampler('ai-image-pro-stabilityai-generate-sampler'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_seed('ai-image-pro-stabilityai-generate-seed'); ?>
                    </div>
                </div>

                <div class="row mt-3 p-2">

                </div>

            </div>

        </div>
        <?php
    }

    private function stability_ai_pane_upscale()
    {
        ?>
        <div class="row">
            <div class="col-12">

                <div class="row mt-3 p-2">

                    <div class="col">
                        <?php $this->stability_ai_scale_dimension('ai-image-pro-stabilityai-upscale-dimension', true); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_upscale_amount('ai-image-pro-stabilityai-upscale-amount'); ?>
                    </div>
                </div>

                <div class="row mt-3 p-2">
                    <div class="col ai-image-pro-upscale-dimensions">
                        <small>
                            <span>
                                <?php echo esc_html__( 'Current dimensions:', 'ai-image-pro' ); ?>
                            </span>
                            <span id="ai-image-pro-stabilityai-upscale-current-dimensions"></span>
                            <br>
                            <span>
                                <?php echo esc_html__( 'New dimensions:', 'ai-image-pro' ); ?>
                            </span>
                            <span id="ai-image-pro-stabilityai-upscale-new-dimensions"></span>
                        </small>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col">

                        <button id="ai-image-pro-stabilityai-upscale-button" type="button" class="btn btn-sm btn-primary float-end mt-1"><i class="bi bi-images"></i> <?php echo esc_html__( 'Upscale', 'ai-image-pro' ); ?></button>
                    </div>
                </div>

            </div>

        </div>
        <?php
    }

    private function stability_ai_pane_edit()
    {
        ?>
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <?php $this->prompt_guide(); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <?php $this->stability_ai_prompt('ai-image-pro-stabilityai-edit-prompt'); ?>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col">

                        <button id="ai-image-pro-stabilityai-perform-edit-button" type="button" class="btn btn-sm float-end btn-primary ai-image-pro-primary-button m-1"><i class="bi bi-check"></i> <?php echo esc_html__( 'Confirm Edit', 'ai-image-pro' ); ?></button>
                        <button id="ai-image-pro-stabilityai-cancel-edit-button" type="button" class="btn btn-sm float-end btn-outline-secondary m-1"><i class="bi bi-x"></i> <?php echo esc_html__( 'Cancel', 'ai-image-pro' ); ?></button>
                        <button id="ai-image-pro-stabilityai-draw-mask-button" type="button" class="btn btn-sm float-end btn-primary ai-image-pro-primary-button disabled m-1">
                            <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Edit image by highlighting the parts you want the AI to edit', 'ai-image-pro' ); ?>">
                                <i class="bi bi-pencil"></i> <?php echo esc_html__( 'Start Editing', 'ai-image-pro' ); ?>
                            </span>
                        </button>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <?php $this->stability_ai_model('ai-image-pro-stabilityai-edit-engine', true); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_styles('ai-image-pro-stabilityai-edit-styles'); ?>
                    </div>

                </div>

                <div class="row mt-3 p-2">

                    <div class="col">
                        <?php $this->stability_ai_number_of_images('ai-image-pro-stabilityai-edit-count'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_number_of_steps('ai-image-pro-stabilityai-edit-steps'); ?>
                    </div>
                </div>

                <div class="row mt-3 p-2">
                    <div class="col">
                        <?php $this->stability_ai_cfg_scale('ai-image-pro-stabilityai-edit-cfg'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_sampler('ai-image-pro-stabilityai-edit-sampler'); ?>
                    </div>

                    <div class="col">
                        <?php $this->stability_ai_seed('ai-image-pro-stabilityai-edit-seed'); ?>
                    </div>
                </div>

            </div>

        </div>
        <?php
    }

    private function stability_ai_prompt($id)
    {
        ?>
        <div class="form-floating">
            <textarea class="form-control ai-image-pro-prompt-input" id="<?php echo $id ?>" rows="5" cols="100" placeholder="<?php echo esc_html__( 'Prompt', 'ai-image-pro' ); ?>"></textarea>
            <label for="<?php echo $id ?>"><?php echo esc_html__( 'Prompt', 'ai-image-pro' ); ?></label>
        </div>
        <?php
    }

    private function stability_ai_model($id, $in_painting = false)
    {
        if ($in_painting) {
            ?>
            <div class="form-group">
                <label for="<?php echo $id ?>" class="ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Model to use in the image in-painting process', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Model', 'ai-image-pro' ); ?>
                </span>
                </label>
                <select class="form-control form-control-sm" id="<?php echo $id ?>">
                    <option value="stable-diffusion-xl-beta-v2-2-2"><?php echo esc_html__( 'Stable Diffusion v2.2.2-XL Beta', 'ai-image-pro' ); ?></option>
                    <option value="stable-diffusion-xl-1024-v0-9"><?php echo esc_html__( 'Stable Diffusion XL v0.9', 'ai-image-pro' ); ?></option>
                    <option value="stable-diffusion-xl-1024-v1-0"><?php echo esc_html__( 'Stable Diffusion XL v1.0', 'ai-image-pro' ); ?></option>
                </select>
            </div>
            <?php

            return;
        }

        $default_model = $this->settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_DEFAULT_MODEL);
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Model to use in the image generation process', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Model', 'ai-image-pro' ); ?>
                </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="stable-diffusion-v1-6" <?php selected('stable-diffusion-v1-6', $default_model, true); ?>><?php echo esc_html__( 'Stable Diffusion v1.6', 'ai-image-pro' ); ?></option>
                <option value="stable-diffusion-xl-beta-v2-2-2" <?php selected('stable-diffusion-xl-beta-v2-2-2', $default_model, true); ?>><?php echo esc_html__( 'Stable Diffusion v2.2.2-XL Beta', 'ai-image-pro' ); ?></option>
                <option value="stable-diffusion-xl-1024-v0-9" <?php selected('stable-diffusion-xl-1024-v0-9', $default_model, true); ?>><?php echo esc_html__( 'Stable Diffusion XL v0.9', 'ai-image-pro' ); ?></option>
                <option value="stable-diffusion-xl-1024-v1-0" <?php selected('stable-diffusion-xl-1024-v1-0', $default_model, true); ?>><?php echo esc_html__( 'Stable Diffusion XL v1.0', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function stability_ai_styles($id)
    {
        // 3d-model analog-film anime cinematic comic-book digital-art enhance fantasy-art isometric line-art low-poly modeling-compound neon-punk origami photographic pixel-art tile-texture
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Style of generated image', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Image style', 'ai-image-pro' ); ?>
                </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value=""><?php echo esc_html__( 'None', 'ai-image-pro' ); ?></option>
                <option value="3d-model"><?php echo esc_html__( '3D Model', 'ai-image-pro' ); ?></option>
                <option value="analog-film"><?php echo esc_html__( 'Analog Film', 'ai-image-pro' ); ?></option>
                <option value="anime"><?php echo esc_html__( 'Anime', 'ai-image-pro' ); ?></option>
                <option value="cinematic"><?php echo esc_html__( 'Cinematic', 'ai-image-pro' ); ?></option>
                <option value="comic-book"><?php echo esc_html__( 'Comic Book', 'ai-image-pro' ); ?></option>
                <option value="digital-art"><?php echo esc_html__( 'Digital Art', 'ai-image-pro' ); ?></option>
                <option value="enhance"><?php echo esc_html__( 'Enhance', 'ai-image-pro' ); ?></option>
                <option value="fantasy-art"><?php echo esc_html__( 'Fantasy Art', 'ai-image-pro' ); ?></option>
                <option value="isometric"><?php echo esc_html__( 'Isometric', 'ai-image-pro' ); ?></option>
                <option value="line-art"><?php echo esc_html__( 'Line Art', 'ai-image-pro' ); ?></option>
                <option value="low-poly"><?php echo esc_html__( 'Low Poly', 'ai-image-pro' ); ?></option>
                <option value="modeling-compound"><?php echo esc_html__( 'Modeling Compound', 'ai-image-pro' ); ?></option>
                <option value="neon-punk"><?php echo esc_html__( 'Neon Punk', 'ai-image-pro' ); ?></option>
                <option value="origami"><?php echo esc_html__( 'Origami', 'ai-image-pro' ); ?></option>
                <option value="photographic"><?php echo esc_html__( 'Photographic', 'ai-image-pro' ); ?></option>
                <option value="pixel-art"><?php echo esc_html__( 'Pixel Art', 'ai-image-pro' ); ?></option>
                <option value="tile-texture"><?php echo esc_html__( 'Tile Texture', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function stability_ai_sampler($id)
    {
        $default_sampler = $this->settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_DEFAULT_SAMPLER);
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'A sampler determines how the image is "calculated". A sampler processes an input (prompt) to produce an output (image). Since these samplers are different mathematically, they will produce difference results for the same prompt.', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Sampler', 'ai-image-pro' ); ?>
                </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="DDIM" <?php selected('DDIM', $default_sampler, true); ?>><?php echo esc_html__( 'DDIM', 'ai-image-pro' ); ?></option>
                <option value="DDPM" <?php selected('DDPM', $default_sampler, true); ?>><?php echo esc_html__( 'DDPM', 'ai-image-pro' ); ?></option>
                <option value="K_DPMPP_2M" <?php selected('K_DPMPP_2M', $default_sampler, true); ?>><?php echo esc_html__( 'K_DPMPP_2M', 'ai-image-pro' ); ?></option>
                <option value="K_DPMPP_2S_ANCESTRAL" <?php selected('K_DPMPP_2S_ANCESTRAL', $default_sampler, true); ?>><?php echo esc_html__( 'K_DPMPP_2S_ANCESTRAL', 'ai-image-pro' ); ?></option>
                <option value="K_DPM_2" <?php selected('K_DPM_2', $default_sampler, true); ?>><?php echo esc_html__( 'K_DPM_2', 'ai-image-pro' ); ?></option>
                <option value="K_DPM_2_ANCESTRAL" <?php selected('K_DPM_2_ANCESTRAL', $default_sampler, true); ?>><?php echo esc_html__( 'K_DPM_2_ANCESTRAL', 'ai-image-pro' ); ?></option>
                <option value="K_EULER" <?php selected('K_EULER', $default_sampler, true); ?>><?php echo esc_html__( 'K_EULER', 'ai-image-pro' ); ?></option>
                <option value="K_EULER_ANCESTRAL" <?php selected('K_EULER_ANCESTRAL', $default_sampler, true); ?>><?php echo esc_html__( 'K_EULER_ANCESTRAL', 'ai-image-pro' ); ?></option>
                <option value="K_HEUN" <?php selected('K_HEUN', $default_sampler, true); ?>><?php echo esc_html__( 'K_HEUN', 'ai-image-pro' ); ?></option>
                <option value="K_LMS" <?php selected('K_LMS', $default_sampler, true); ?>><?php echo esc_html__( 'K_LMS', 'ai-image-pro' ); ?></option>
            </select>
        </div>
        <?php
    }

    private function stability_ai_width($id)
    {
        $default_width = $this->settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_DEFAULT_IMAGE_WIDTH);
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Width of generated image in pixels', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Width', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" step="64" min="128" max="1536" value="<?php echo $default_width ?>">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border"><?php echo $default_width ?></span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_height($id)
    {
        $default_height = $this->settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_DEFAULT_IMAGE_HEIGHT);
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Height of generated image in pixels', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Height', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" step="64" min="128" max="1536" value="<?php echo $default_height ?>">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border"><?php echo $default_height ?></span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_scale_dimension($id)
    {
        ?>
        <div class="form-group">
            <label for="<?php echo $id ?>" class="ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'You can either scale the width or the height of an image.', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Scaling dimension', 'ai-image-pro' ); ?>
                </span>
            </label>
            <select class="form-control form-control-sm" id="<?php echo $id ?>">
                <option value="width"><?php echo esc_html__( 'Width', 'ai-image-pro' ); ?></option>
                <option value="height"><?php echo esc_html__( 'Height', 'ai-image-pro' ); ?></option>
            </select>
        </div>

        <?php
    }

    private function stability_ai_upscale_amount($id)
    {
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Upscale Amount', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Upscale Amount', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" value="512" step="64" min="512" max="4096">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border">1</span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_number_of_images($id)
    {
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Number of Images to generate', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Number of Images', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" value="1" step="1" min="1" max="10">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border">1</span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_number_of_steps($id)
    {
        $default_steps = $this->settings->get_option(AIImagePro_Settings::OPTION_STABILITY_AI_NUMBER_OF_STEPS);
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Generation steps control how many times the image is sampled. Increasing the number of steps might give you better results, up to a point where there\'re diminishing returns. More steps would also cost you more.', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Number of Steps', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" value="<?php echo $default_steps ?>" step="1" min="10" max="150">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border">30</span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_cfg_scale($id)
    {
        ?>
        <div class="row">
            <div class="col-10">
                <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                    <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Prompt strength (CFG scale) controls how much the final image will adhere to your prompt. Lower values would give the model more "creativity", while higher values will produce a final image that\'s close to your prompt.', 'ai-image-pro' ); ?>">
                        <?php echo esc_html__( 'Prompt strength', 'ai-image-pro' ); ?>
                    </span>
                </label>
                <input type="range" class="form-range ai-image-pro-range" id="<?php echo $id ?>" value="7" step="1" min="0" max="35">
            </div>
            <div class="col-2 mt-4 text-center justify-content-center p-0">
                <span class="ai-image-pro-range-value border">7</span>
            </div>
        </div>
        <?php
    }

    private function stability_ai_seed($id)
    {
        ?>
        <div class="mb-3">
            <label for="<?php echo $id ?>" class="form-label ai-image-pro-label">
                <span class="d-inline-block ai-image-pro-popover" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo esc_html__( 'Seed is a number used to initialize the image generation. Using a certain seed with same settings will produce the same image. "0" means a random seed will be used everytime.', 'ai-image-pro' ); ?>">
                    <?php echo esc_html__( 'Seed', 'ai-image-pro' ); ?>
                </span>
            </label>
            <input type="number" class="form-control form-control-sm" id="<?php echo $id ?>" value="0">
        </div>
        <?php
    }

    private function prompt_guide()
    {
        ?>
            <span class="d-inline-block ai-image-pro-popover ai-image-pro-prompt-guide-container" data-bs-toggle="popover-with-click" data-bs-content="<?php echo esc_html__( 'Prompting is an art in itself. Check the following resources to understand how to write better prompts:', 'ai-image-pro' ); ?> <a href='https://strikingloo.github.io/stable-diffusion-vs-dalle-2' target='_blank'><?php echo esc_html__( 'Prompt guide', 'ai-image-pro' ); ?></a>, <a href='https://proximacentaurib.notion.site/e28a4f8d97724f14a784a538b8589e7d?v=42948fd8f45c4d47a0edfc4b78937474&p=9aa9c42e061146fa8a39af4f33d46d48&pm=s' target='_blank'><?php echo esc_html__( 'Stable Diffusion art styles', 'ai-image-pro' ); ?></a>, <a href='https://www.youtube.com/results?search_query=how+to+write+prompts+dalle' target='_blank'><?php echo esc_html__( 'Dall.E prompt videos', 'ai-image-pro' ); ?></a>, <a href='https://www.youtube.com/results?search_query=how+to+write+prompts+stable+diffusion' target='_blank'><?php echo esc_html__( 'Stable Diffusion prompt videos', 'ai-image-pro' ); ?></a> ">
                <a class="ai-image-pro-prompt-guide"><?php echo esc_html__( '?', 'ai-image-pro' ); ?></a>
            </span>
        <?php
    }


    private function toolbar()
    {
        ?>
        <div class="ai-image-pro-editor-toolbar m-2 text-center">
            <div class="ai-image-pro-editor-toolbar-item">
                <button id="ai-image-pro-editor-toolbar-item-crop-button" type="button" class="btn btn-sm btn-outline-secondary disabled">
                    <i class="bi bi-crop"></i>
                    <span><?php echo esc_html__( 'Crop', 'ai-image-pro' ); ?></span>
                </button>
                <button id="ai-image-pro-editor-toolbar-item-filters-button" type="button" class="btn btn-sm btn-outline-secondary disabled">
                    <i class="bi bi-eyeglasses"></i>
                    <span><?php echo esc_html__( 'Filters', 'ai-image-pro' ); ?></span>
                </button>
                <button id="ai-image-pro-editor-toolbar-item-fine-tunes-button" type="button" class="btn btn-sm btn-outline-secondary disabled">
                    <i class="bi bi-sliders2-vertical"></i>
                    <span><?php echo esc_html__( 'Fine-tune', 'ai-image-pro' ); ?></span>
                </button>
            </div>

        </div>
        <?php
    }

    private function toolbarPanes()
    {
        ?>
        <div class="ai-image-pro-editor-toolbar-panes">
            <div id="ai-image-pro-editor-toolbar-pane-crop">
                <button id="ai-image-pro-editor-toolbar-item-crop-cancel-button" type="button" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-x"></i>
                    <span><?php echo esc_html__( 'Cancel', 'ai-image-pro' ); ?></span>
                </button>
                <button id="ai-image-pro-editor-toolbar-item-crop-1-1-ratio" type="button" class="btn btn-sm btn-outline-secondary ms-2 me-2">
                    <i class="bi bi-square"></i>
                    <span><?php echo esc_html__( '1:1', 'ai-image-pro' ); ?></span>
                </button>
                <button id="ai-image-pro-editor-toolbar-item-crop-confirm-button" type="button" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-check"></i>
                    <span><?php echo esc_html__( 'Confirm', 'ai-image-pro' ); ?></span>
                </button>
            </div>
            <div id="ai-image-pro-editor-toolbar-pane-filters">

            </div>
            <div id="ai-image-pro-editor-toolbar-pane-fine-tunes">
                <div id="ai-image-pro-editor-toolbar-pane-fine-tunes-buttons">

                </div>
                <div id="ai-image-pro-editor-toolbar-pane-fine-tunes-ranges">

                </div>
            </div>
        </div>
        <?php
    }

    public function enqueue_scripts( $hook ) {
        if ( 'toplevel_page_aiimagepro' != $hook && 'aiimagepro' != $hook ) {
            return;
        }

        $version = aiimagepro_get_plugin_version();
        if ($version === false) {
            $version = rand( 1, 10000000 );
        }

        wp_enqueue_script( 'fabric', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/js/fabric.js', array(), $version );
        wp_enqueue_script( 'aiimagepro-editor', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/js/editor.js', array('jquery', 'fabric', 'the-cropper'), $version );
        wp_enqueue_script( 'bootstrap', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/js/bootstrap.bundle.min.js', array(), $version );
        wp_enqueue_script( 'the-cropper', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/js/cropper.min.js', array(), $version );

        wp_enqueue_style( 'aiimagepro-editor', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/editor.css', array(), $version );
        wp_enqueue_style( 'bootstrap', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/bootstrap.min.css', array(), $version );
        wp_enqueue_style( 'bootstrap-icons', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/bootstrap-icons.css', array(), $version );
        wp_enqueue_style( 'the-cropper', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/cropper.min.css', array(), $version );
        wp_enqueue_style( 'google-font', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/fonts.css', array(), $version );

        // if the page has parameter embedded=true, then add the embedded css file
        if (isset($_GET['embedded']) && $_GET['embedded'] == 'true') {
            wp_enqueue_style( 'aiimagepro-embedded', rtrim(plugin_dir_url( __FILE__ ), '/') . '/../../assets/css/embedded.css', array(), $version );
        }

        wp_enqueue_media();  // for media library
    }

    public function editor_shortcode ($args) {
        $enabled_frontend = get_option(AIImagePro_Settings::OPTION_ENABLE_IN_FRONTEND);
        if ($enabled_frontend != '1') {
            return '';
        }

        $enabled_frontend_for_role = get_option(AIImagePro_Settings::OPTION_ENABLE_IN_FRONTEND_FOR_ROLE) ?? 'any';
        // role of the current user
        // admin can always see the editor (manage_options)
        $user = wp_get_current_user();
        if ($enabled_frontend_for_role != 'any' && !in_array($enabled_frontend_for_role, $user->roles) && !current_user_can('manage_options')) {

            $message_for_non_logged_in_users = get_option(AIImagePro_Settings::OPTION_MESSAGE_FOR_NON_LOGGED_IN_USERS);

            if ($message_for_non_logged_in_users != '') {
                return '<div>' . $message_for_non_logged_in_users . '</div>';
            }

            $redirect_url = get_option(AIImagePro_Settings::OPTION_REDIRECT_FOR_NON_LOGGED_IN_USERS);

            if ($redirect_url != '') {
                // echo js to redirect
                return '<script>window.location.href = "' . $redirect_url . '";</script>';
            }

            return '';
        }

        $editor_id = rand(0, 10000000);
        $plugin_version = aiimagepro_get_plugin_version();
        $width = $args['width'] ?? '100%';
        $height = $args['height'] ?? '1000px';
        $url = admin_url('admin.php?page=aiimagepro');
        $show_logo = (isset($args['show_logo']) && $args['show_logo'] == '1') ? '1': '0';
        $show_credits = (isset($args['show_credits']) && $args['show_credits'] == '1') ? '1': '0';
        $scrolling = $args['scrolling'] ?? 'no';

        return '<div style="border: 0; text-align: center; align-content: center; "><iframe style="border: 0;" id="ai-image-pro-editor-' . $editor_id . '" src="' . $url . '&embedded=true&v=' . $plugin_version . '&editorId=' . $editor_id . '&showLogo=' . $show_logo . '&showCredits=' . $show_credits . '" width="' . $width . '" height="' . $height . '" scrolling="' . $scrolling . '"></iframe></div>';
    }

    public function filter_media_library($wp_query_obj) {
        if (current_user_can('manage_options')) {
            return;
        }

        if ((isset($_GET['page']) && $_GET['page'] == 'aiimagepro') ||
            ($_SERVER['SCRIPT_NAME'] == '/wp-admin/admin-ajax.php' && ($_POST['action'] ?? '') == 'query-attachments')
        ) {

            // Get the current user's ID
            $current_user_id = get_current_user_id();

            // Set the query to only retrieve the images uploaded by the current user
            $wp_query_obj->set('author', $current_user_id);
        }
    }

}
